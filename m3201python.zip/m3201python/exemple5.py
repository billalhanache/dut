#!/usr/bin/python

from matplotlib.pyplot import *
from numpy.random import *

bar([1, 2, 3, 4, 5], [442, 75, 49, 12, 20])
ylabel("Nombre de voitures")

title("Nombre de passagers par voiture")
show()