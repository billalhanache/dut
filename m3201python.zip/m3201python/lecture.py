#!/usr/bin/python

from numpy import *
from matplotlib.pyplot import *
import pickle

f=open('data1.txt','rb')
x=pickle.load(f)
f.close()

print(x)
moyenne = sum(x) / x.shape[0]

print('Moyenne : %f' % moyenne)