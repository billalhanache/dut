#!/usr/bin/python

from numpy import *
from matplotlib.pyplot import *

