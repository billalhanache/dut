package personne;

import java.util.LinkedList;
import java.util.List;

public class Memento implements Cloneable {

	private String nom;

	private List<String> prenoms;

	public Memento(){
		this.nom = null;
		this.prenoms = new LinkedList<String>();
	}
	
	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}
	
	public String getPremierPrenom() {
		if (this.prenoms.size() > 0)
			return this.prenoms.get(0);
		else
			return null;
	}
	
	public String getDeuxiemePrenom() {
		if (this.prenoms.size() > 1)
			return this.prenoms.get(1);
		else
			return null;
	}
	
	public String getTroisiemePrenom() {
		if (this.prenoms.size() > 2)
			return this.prenoms.get(2);
		else
			return null;
	}
	
	public boolean ajoutPrenom(String prenom) {
		if (this.prenoms.size() < 3){
			this.prenoms.add(prenom);
			return true;
		}
		return false;
	}
	
	public Memento clone() {
		Memento memento = null;
		try {
			memento = (Memento) super.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		memento.prenoms = new LinkedList<String>();
		for (String s : this.prenoms) {
			memento.prenoms.add(s);
		}
		return memento;
	}

}
