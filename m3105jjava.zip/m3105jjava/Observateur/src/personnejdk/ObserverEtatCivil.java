package personnejdk;

import java.util.Observable;
import java.util.Observer;

public class ObserverEtatCivil implements Observer {
	private void changementDeNom(Personne p) {
		System.out.println("Changement de nom " + p.getBefore().getNom() + " devient " + p.getAfter().getNom());
		System.out.println("Supprimmer carte d'identit� pour " + p.getBefore().getNom());
		System.out.println("Reg�n�rer carte d'identit� pour " + p.getAfter().getNom());
	}

	private void ajouterPrenom(Personne p) {
		System.out.print("Ajouter pr�nom carte d'identit� pour " + p.getAfter().getNom());
		if (! p.getAfter().getPremierPrenom().equals(p.getBefore().getPremierPrenom()))
			System.out.print( " " + p.getAfter().getPremierPrenom());
		if (p.getAfter().getDeuxiemePrenom() != null)
			if (! p.getAfter().getDeuxiemePrenom().equals(p.getBefore().getDeuxiemePrenom()))
				System.out.print( " " + p.getAfter().getDeuxiemePrenom());
		if (p.getAfter().getTroisiemePrenom() != null)
			if (! p.getAfter().getTroisiemePrenom().equals(p.getBefore().getTroisiemePrenom()))
				System.out.print( " " + p.getAfter().getTroisiemePrenom());
		System.out.println();
	}

	@Override
	public void update(Observable s, Object obj) {
		Personne p = (Personne) s;
		if (!p.getAfter().getNom().equals(p.getBefore().getNom()))
			this.changementDeNom(p);
		else
			this.ajouterPrenom(p);
	}
}
