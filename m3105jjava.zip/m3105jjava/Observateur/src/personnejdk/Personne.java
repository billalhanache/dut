package personnejdk;

import java.util.Observable;

public class Personne extends Observable {
	
	private Memento before;
	private Memento after;
	
	public Personne(String nom, String prenom){
		this.before = new Memento();
		this.after = new Memento();
		this.after.setNom(nom);
		this.after.ajoutPrenom(prenom);
		this.before = this.after.clone();
	}

	public String getNom() {
		return this.after.getNom();
	}

	public void setNom(String nom) {
		if (!this.after.getNom().equals(nom)){
			this.after.setNom(nom);
			this.notifyObservers();
			this.before = this.after.clone();
		}
	}

	public String getPremierPrenom(){
		return this.after.getPremierPrenom();
	}

	public String getDeuxiemePrenom(){
		return this.after.getDeuxiemePrenom();
	}
	
	public String getTroisemePrenom() {
		return this.after.getTroisiemePrenom();
	}
	
	public void ajoutPrenom(String prenom) {
		if (this.after.ajoutPrenom(prenom)){
			this.notifyObservers();
			this.before = this.after.clone();
		}
	}

	public Memento getBefore() {
		return before;
	}

	public Memento getAfter() {
		return after;
	}
	
	public void notifyObservers() {
		this.setChanged();
		super.notifyObservers();
	}
	
}
