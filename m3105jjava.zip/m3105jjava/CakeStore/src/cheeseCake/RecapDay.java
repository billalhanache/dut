package cheeseCake;

import java.util.LinkedList;

public class RecapDay {
	private static RecapDay journalOfTheDay;
	private LinkedList<CheeseCake> cakesOfTheDay;
	
	private RecapDay() {
		this.cakesOfTheDay = new LinkedList<>();
	}
	
	public static synchronized RecapDay getJournalOfTheDay() {
		if(journalOfTheDay == null) {
			journalOfTheDay = new RecapDay();
		}
		return journalOfTheDay;
	}
	
	public void addNewOrder(CheeseCake cake) {
		this.cakesOfTheDay.add(cake);
	}
	
	@Override
	public String toString() {
		String result = "Recap Of The Day : \n";
		for(CheeseCake cake : this.cakesOfTheDay) {
			result += cake.toString() + "\n";
		}
		return result;
	}
}
