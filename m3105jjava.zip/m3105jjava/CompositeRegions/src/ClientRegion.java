
public class ClientRegion {
	public static void main(String[] args) {
		Departement ardennes= new Departement("Ardennes", 8, 289000, 5229);
		Departement ariege= new Departement("Ariège", 9, 152286, 4890);
		Departement aube= new Departement("Aube", 10, 301327, 6004);
		Departement aude= new Departement("Aude", 11, 362339, 6139);
		Departement aveyron= new Departement("Aveyron", 12, 275813, 8735);
		Departement gard= new Departement("Gard", 30, 733201, 5853);
		Departement hauteGaronne= new Departement("Haute-Garonne", 31, 1299000, 6309);
		Departement gers= new Departement("Gers", 32, 190276, 6257);
		Departement herault= new Departement("Hérault", 34, 1092000, 6101);
		Departement lot= new Departement("Lot", 46, 173758, 5217);
		Departement lozere= new Departement("Lozère", 48, 76607, 5167);
		Departement marne= new Departement("Marne", 51, 569999, 8162);
		Departement hauteMarne= new Departement("Haute-Marne", 52, 181521, 6211);
		Departement meurtheEtMoselle= new Departement("Meurthe-et-Moselle", 54, 731004, 5246);
		Departement meuse= new Departement("Meuse", 55, 192094, 6211);
		Departement moselle= new Departement("Moselle", 57, 1047000, 6216);
		Departement hautesPyrénées= new Departement("Hautes-Pyrénées", 65, 228868, 4464);
		Departement pyrénéesOrientales= new Departement("Pyrénées Orientales", 66, 462705, 4116);
		Departement basRhin= new Departement("Bas-Rhin", 67, 1109000, 4755);
		Departement hautRhin= new Departement("Haut-Rhin", 68, 758723, 3525);
		Departement tarn= new Departement("Tarn", 81, 381927, 5758);
		Departement tarnEtGaronne= new Departement("Tarn et Garonne", 82, 250342, 3718);
		Departement vosges= new Departement("Vosges", 88, 375226, 5874);
		Region alsace= new Region("Alsace");alsace.add(basRhin);
		alsace.add(hautRhin);Region champagneArdennes= new Region("Champagne-Ardennes");
		champagneArdennes.add(ardennes);champagneArdennes.add(aube);
		champagneArdennes.add(hauteMarne);champagneArdennes.add(marne);
		Region lorraine= new Region("Lorraine");lorraine.add(meurtheEtMoselle);
		lorraine.add(meuse);lorraine.add(moselle);lorraine.add(vosges);
		Region languedocRoussilon= new Region("Languedoc-Roussillon");
		languedocRoussilon.add(aude);languedocRoussilon.add(gard);
		languedocRoussilon.add(herault);languedocRoussilon.add(lozere);
		languedocRoussilon.add(pyrénéesOrientales);
		Region midiPyrénées= new Region("Midi-Pyrénées");
		midiPyrénées.add(ariege);
		midiPyrénées.add(aveyron);
		midiPyrénées.add(hauteGaronne);
		midiPyrénées.add(gers);
		midiPyrénées.add(lot);
		midiPyrénées.add(hautesPyrénées);
		midiPyrénées.add(tarn);
		midiPyrénées.add(tarnEtGaronne);
		Region grandEst= new Region("Grand Est");
		grandEst.add(alsace);
		grandEst.add(champagneArdennes);
		grandEst.add(lorraine);
		Region occitanie= new Region("Occitanie");
		occitanie.add(languedocRoussilon);
		occitanie.add(midiPyrénées);
		Region.FRANCE.add(grandEst);
		Region.FRANCE.add(occitanie);
		
		System.out.println(Region.FRANCE.toString(""));
		
		aveyron.changerDeRegion(midiPyrénées, languedocRoussilon);
		alsace.devientGrandeRegion(grandEst);
		
		System.out.println(Region.FRANCE.toString(""));
	}
}
