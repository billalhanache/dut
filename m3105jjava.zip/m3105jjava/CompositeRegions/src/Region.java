import java.util.List;
import java.util.ArrayList;

public class Region extends EntiteAdministrative {
	private List<EntiteAdministrative> children;
	
	public static final Region FRANCE = new Region("France");
	
	public Region(String libelle) {
		super(libelle);
		this.children = new ArrayList<>();
	}
	
	public void add(EntiteAdministrative child) {
		this.children.add(child);
	}
	
	public void remove(EntiteAdministrative child) {
		this.children.remove(child);
	}
	
	public List<EntiteAdministrative> getChildren() {
		return this.children;
	}
	
	public int getNbHabitants() {
		int nb = 0;
		for(EntiteAdministrative child : this.children) {
			nb += child.getNbHabitants();
		}
		return nb;
	}
	
	public int getSuperficie() {
		int superficie = 0;
		for(EntiteAdministrative child : this.children) {
			superficie += child.getSuperficie();
		}
		return superficie;
	}
	
	public String toString(String nbEspaces) {
		String result = nbEspaces + this.libelle + this.toStringSuperficie() + this.toStringNbHabitants() + "\n";
		nbEspaces += "  ";
		for(EntiteAdministrative entite : this.children) {
			result += entite.toString(nbEspaces)+"\n";
		}
		return result;
	}
	
	public void devientGrandeRegion(Region oldRegion) throws RuntimeException {
		if(oldRegion == null) throw new RuntimeException("Null");
		oldRegion.remove(this);
		Region.FRANCE.add(this);
	}
}
