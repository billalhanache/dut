

import java.util.Map;
import java.util.HashMap;

public class GestionDesCompetences {
	
	private Map <String,String> competencesCommunes;
	private Map <String,String> competencesDepartements;
	private Map <String,String> competencesRegions;
	private Map <String,String> competencesEtat;
	
	public GestionDesCompetences() {
		
		// creation des competences communales par Domaine
		this.competencesCommunes = new HashMap<String,String>();
		this.competencesCommunes.put("Enseignement","ecoles (batiments)");
		this.competencesCommunes.put("Culture et vie sociale","education, creation, bibliotheques, musees, archives");
		this.competencesCommunes.put("Enfance","creches, centres de loisirs");
		this.competencesCommunes.put("sports et loisirs","equipements et subventions, tourisme");
		this.competencesCommunes.put("Action sociale et medico-sociale","CCAS : centre communal d'action sociale");
		this.competencesCommunes.put("Urbanisme","plan local d'urbanisme, schema de coherence territoriale, permis de construire, zone d'amenagement concert");
		this.competencesCommunes.put("Amenagement du territoir","Schema regional (avis, approbation)");
		this.competencesCommunes.put("Environnement","Espaces naturels, collecte et traitement des dechets, Eau (distribution, assainissement), energie (distribution)");
		this.competencesCommunes.put("Grands equipements","Ports de plaisance, Aerodromes");
		this.competencesCommunes.put("Developpement economique","Aides indirectes");
		this.competencesCommunes.put("Securite","Police municipale, Circulation et stationnement, Prevention de la delinquance");
		
		// creation des competences departementales par Domaine
		this.competencesDepartements = new HashMap<String,String>();
		this.competencesDepartements.put("Enseignement","Colleges (betiments, personnels ouvriers, techniciens et de service)");
		this.competencesDepartements.put("Culture et vie sociale","education, creation, bibliotheques, musees, archives");
		this.competencesDepartements.put("Action sociale et medico-sociale","protection maternelle et infantile, aide sociale a l'enfance");
		this.competencesDepartements.put("Amenagement du territoir","Schema regional (avis, approbation)");
		this.competencesDepartements.put("Environnement","Espaces naturels, Dechets (plan departemental), participation au schema d'amenagement et de gestion des eaux");
		this.competencesDepartements.put("Grands equipements","Ports maritimes, de commerce et de peche, Aerodromes");
		this.competencesDepartements.put("Developpement economique","Aides indirectes");
		this.competencesDepartements.put("Securite","Circulation, Prevention de la delinquance, Incendie et secours");
		
		// creation des competences regionales par Domaine
		this.competencesRegions = new HashMap<String,String>();
		this.competencesRegions.put("Formation Professionnelle et Apprentissage","Definition de la politique regionale et mise en euvre");
		this.competencesRegions.put("Enseignement","Lycees (betiments, personnels ouvriers, techniciens et de service)");
		this.competencesRegions.put("Culture et vie sociale","patrimoine, education, creation, bibliotheques, musees, archives");
		this.competencesRegions.put("sports et loisirs","subventions, tourisme");
		this.competencesRegions.put("Amenagement du territoir","Schema regional (elaboration), contrat de projet etat/region");
		this.competencesRegions.put("Environnement","Espaces naturels, Parcs Regionaux, participation au schema deamenagement et de gestion des eaux");
		this.competencesRegions.put("Grands equipements","Ports fluviaux, Aerodromes");
		this.competencesRegions.put("Developpement economique","Aides directes et indirectes");
		
		// creation des competences etatiques par Domaine
		this.competencesEtat = new HashMap<String,String>();
		this.competencesEtat.put("Formation Professionnelle et Apprentissage","Definition de la politique nationale et mise en euvre pour certains publics");
		this.competencesEtat.put("Enseignement","Universites (betiments, personnel), Politique educative");
		this.competencesEtat.put("Culture et vie sociale","patrimoine, education, creation, bibliotheques, musees, archives");
		this.competencesEtat.put("sports et loisirs","formation, subventions, tourisme");
		this.competencesEtat.put("Action sociale et medico-sociale","allocation deadulte handicape, centre dehebergement et de reinsertion sociale");
		this.competencesEtat.put("Urbanisme","projet deinteret general, operations deinteret national, directive territoriale deamenagement");
		this.competencesEtat.put("Amenagement du territoir","politique d'amenagement du territoir, contrat de projet etat/region");
		this.competencesEtat.put("Environnement","Espaces naturels, Parcs Nationaux, schema deamenagement et de gestion des eaux, energie");
		this.competencesEtat.put("Grands equipements","Ports autonomes et deinteret national, Voies navigables, Aerodromes");
		this.competencesEtat.put("Developpement economique","Politique economique");
		this.competencesEtat.put("Securite","Police generale et polices speciales");
	}
	
	public void rechercherUneCompetenceDuBasVersLeHaut(String competence) {
		System.out.println("Recherche de la responsabilite de la competence " + competence);
		
		System.out.print("Commune : ");
		boolean rien = true;
		for (String s:this.competencesCommunes.values()) {
			String competences = s.toLowerCase();
			if (competences.contains(competence)) {
				System.out.print(s);
				rien = false;
			}				
		}
		if (rien)
			System.out.println("-");
		else
			System.out.println();
		
		System.out.print("Departement : ");
		rien = true;
		for (String s:this.competencesDepartements.values()) {
			String competences = s.toLowerCase();
			if (competences.contains(competence)) {
				System.out.print(s);
				rien = false;
			}				
		}
		if (rien)
			System.out.println("-");
		else
			System.out.println();
		
		System.out.print("Region : ");
		rien = true;
		for (String s:this.competencesRegions.values()) {
			String competences = s.toLowerCase();
			if (competences.contains(competence)) {
				System.out.print(s);
				rien = false;
			}				
		}
		if (rien)
			System.out.println("-");
		else
			System.out.println();
		
		System.out.print("Etat: ");
		rien = true;
		for (String s:this.competencesEtat.values()) {
			String competences = s.toLowerCase();
			if (competences.contains(competence)) {
				System.out.print(s);
				rien = false;
			}				
		}
		if (rien)
			System.out.println("-");
		else
			System.out.println();
	}

	public void rechercherUneCompetenceDuHautVersLeBas(String competence) {
		System.out.println("Recherche de la responsabilite de la competence " + competence);
		
		System.out.print("Etat: ");
		boolean rien = true;
		for (String s:this.competencesEtat.values()) {
			String competences = s.toLowerCase();
			if (competences.contains(competence)) {
				System.out.print(s);
				rien = false;
			}				
		}
		if (rien)
			System.out.println("-");
		else
			System.out.println();
		
		System.out.print("Region : ");
		rien = true;
		for (String s:this.competencesRegions.values()) {
			String competences = s.toLowerCase();
			if (competences.contains(competence)) {
				System.out.print(s);
				rien = false;
			}				
		}
		if (rien)
			System.out.println("-");
		else
			System.out.println();
		
		System.out.print("Departement : ");
		rien = true;
		for (String s:this.competencesDepartements.values()) {
			String competences = s.toLowerCase();
			if (competences.contains(competence)) {
				System.out.print(s);
				rien = false;
			}				
		}
		if (rien)
			System.out.println("-");
		else
			System.out.println();
		
		System.out.print("Commune : ");
		rien = true;
		for (String s:this.competencesCommunes.values()) {
			String competences = s.toLowerCase();
			if (competences.contains(competence)) {
				System.out.print(s);
				rien = false;
			}				
		}
		if (rien)
			System.out.println("-");
		else
			System.out.println();
	}
	
	public void afficherCompetencesDomaineDuBasVersLeHaut(String domaine) {
		System.out.println("afficher les competences du domaine " + domaine);
		
		System.out.print("Commune : ");
		String competences = this.competencesCommunes.get(domaine);
		if (competences == null)
			System.out.println("-");
		else
			System.out.println(competences);
		
		System.out.print("Departement : ");
		competences = this.competencesDepartements.get(domaine);
		if (competences == null)
			System.out.println("-");
		else
			System.out.println(competences);
		
		System.out.print("Region : ");
		competences = this.competencesRegions.get(domaine);
		if (competences == null)
			System.out.println("-");
		else
			System.out.println(competences);
		
		System.out.print("Etat : ");
		competences = this.competencesEtat.get(domaine);
		if (competences == null)
			System.out.println("-");
		else
			System.out.println(competences);
	}
	
	public static void main(String[] args) {
		GestionDesCompetences france = new GestionDesCompetences();
		
		france.rechercherUneCompetenceDuBasVersLeHaut("police");
		System.out.println();
		france.rechercherUneCompetenceDuBasVersLeHaut("aerodrome");
		System.out.println();
		france.rechercherUneCompetenceDuBasVersLeHaut("handicap");
		System.out.println();
		france.rechercherUneCompetenceDuHautVersLeBas("port");
		System.out.println();
		france.rechercherUneCompetenceDuHautVersLeBas("universite");
		System.out.println();
		france.afficherCompetencesDomaineDuBasVersLeHaut("Enseignement");
		System.out.println();
		france.afficherCompetencesDomaineDuBasVersLeHaut("Urbanisme");
	}

}
