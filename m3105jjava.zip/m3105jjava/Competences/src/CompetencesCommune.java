
public class CompetencesCommune extends Competences {

	public CompetencesCommune(Competences suivant) {
		super("Commune", suivant);
		
		this.competences.put("Enseignement","ecoles (batiments)");
		this.competences.put("Culture et vie sociale","education, creation, bibliotheques, musees, archives");
		this.competences.put("Enfance","creches, centres de loisirs");
		this.competences.put("sports et loisirs","equipements et subventions, tourisme");
		this.competences.put("Action sociale et medico-sociale","CCAS : centre communal d'action sociale");
		this.competences.put("Urbanisme","plan local d'urbanisme, schema de coherence territoriale, permis de construire, zone d'amenagement concert");
		this.competences.put("Amenagement du territoir","Schema regional (avis, approbation)");
		this.competences.put("Environnement","Espaces naturels, collecte et traitement des dechets, Eau (distribution, assainissement), energie (distribution)");
		this.competences.put("Grands equipements","Ports de plaisance, Aerodromes");
		this.competences.put("Developpement economique","Aides indirectes");
		this.competences.put("Securite","Police municipale, Circulation et stationnement, Prevention de la delinquance");
	}
	
	public CompetencesCommune() {
		this(null);
	}

}
