import java.util.HashMap;
import java.util.Map;

public abstract class Competences {
	private String nom;
	protected Map<String, String> competences;
	private Competences suivant;
	
	public Competences(String nom, Competences suivant) {
		this.nom = nom;
		this.competences = new HashMap<>();
		this.suivant = suivant;
	}
	
	public void rechercherUneCompetence(String competence) {
		System.out.print(this.nom + " : ");
		boolean rien = true;
		for (String s:this.competences.values()) {
			String competences = s.toLowerCase();
			if (competences.contains(competence)) {
				System.out.print(s);
				rien = false;
			}				
		}
		if (rien) System.out.println("-");
		else System.out.println();
		
		if(this.suivant != null) {
			this.suivant.rechercherUneCompetence(competence);
		}
	}
	
	public void afficherCompetencesParDomaine(String domaine) {
		System.out.print(this.nom + " : ");
		String competences = this.competences.get(domaine);
		if (competences == null) System.out.println("-");
		else System.out.println(competences);
		
		if(this.suivant != null) {
			this.suivant.afficherCompetencesParDomaine(domaine);
		}
	}

}
