public class GestionDesCompetencesRefactorise {
	public void rechercherUneCompetenceDuBasVersLeHaut(String competence) {
		System.out.println("Recherche de la responsabilite de la competence " + competence);

		new CompetencesCommune(new CompetencesDepartement(new CompetencesRegion(new CompetencesEtat()))).rechercherUneCompetence(competence);
	}

	public void rechercherUneCompetenceDuHautVersLeBas(String competence) {
		System.out.println("Recherche de la responsabilite de la competence " + competence);

		new CompetencesEtat(new CompetencesRegion(new CompetencesDepartement(new CompetencesCommune()))).rechercherUneCompetence(competence);
	}

	public void afficherCompetencesDomaineDuBasVersLeHaut(String domaine) {
		System.out.println("afficher les competences du domaine " + domaine);

		new CompetencesCommune(new CompetencesDepartement(new CompetencesRegion(new CompetencesEtat()))).afficherCompetencesParDomaine(domaine);
	}

	public void afficherCompetencesDomaineRegionDepartementCommuneEtat(String domaine) {
		System.out.println("afficher les competences du domaine " + domaine);

		new CompetencesRegion(new CompetencesDepartement(new CompetencesCommune(new CompetencesEtat()))).afficherCompetencesParDomaine(domaine);
	}

	public static void main(String[] args) {
		GestionDesCompetencesRefactorise france = new GestionDesCompetencesRefactorise();

		france.rechercherUneCompetenceDuBasVersLeHaut("police");
		System.out.println();
		france.rechercherUneCompetenceDuBasVersLeHaut("aerodrome");
		System.out.println();
		france.rechercherUneCompetenceDuBasVersLeHaut("handicap");
		System.out.println();
		france.rechercherUneCompetenceDuHautVersLeBas("port");
		System.out.println();
		france.rechercherUneCompetenceDuHautVersLeBas("universite");
		System.out.println();
		france.afficherCompetencesDomaineDuBasVersLeHaut("Enseignement");
		System.out.println();
		france.afficherCompetencesDomaineDuBasVersLeHaut("Urbanisme");
	}

}
