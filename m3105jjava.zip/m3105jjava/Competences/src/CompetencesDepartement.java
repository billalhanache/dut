
public class CompetencesDepartement extends Competences {

	public CompetencesDepartement(Competences suivant) {
		super("Departement", suivant);
		
		this.competences.put("Enseignement","Colleges (betiments, personnels ouvriers, techniciens et de service)");
		this.competences.put("Culture et vie sociale","education, creation, bibliotheques, musees, archives");
		this.competences.put("Action sociale et medico-sociale","protection maternelle et infantile, aide sociale a l'enfance");
		this.competences.put("Amenagement du territoir","Schema regional (avis, approbation)");
		this.competences.put("Environnement","Espaces naturels, Dechets (plan departemental), participation au schema d'amenagement et de gestion des eaux");
		this.competences.put("Grands equipements","Ports maritimes, de commerce et de peche, Aerodromes");
		this.competences.put("Developpement economique","Aides indirectes");
		this.competences.put("Securite","Circulation, Prevention de la delinquance, Incendie et secours");
	}
	
	public CompetencesDepartement() {
		this(null);
	}

}
