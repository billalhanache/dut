package atm;

import java.util.List;

public class CalculatorBilletsGC20 extends CalculatorBillets {

	public CalculatorBilletsGC20(CalculatorBillets suivant) {
		super(suivant);
	}	

	public void donnerBillets(Montant montant, List<Couple> proposition, EtatDistributeur etat) {
		int nBillets = Math.min(montant.getMontant() / 20, etat.getNb20Disponible());
		montant.setMontant(montant.getMontant() - nBillets * 20);
		etat.setNb20Disponible(etat.getNb20Disponible() - nBillets);

		if(nBillets > 0) {
			proposition.add(new Couple(20, nBillets));
		}

		super.donnerBillets(montant, proposition, etat);
	}

}
