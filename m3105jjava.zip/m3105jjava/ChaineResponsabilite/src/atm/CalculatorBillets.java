package atm;

import java.util.List;

import atm.Couple;
import atm.EtatDistributeur;
import atm.Montant;

public abstract class CalculatorBillets {
	private CalculatorBillets suivant;

	public CalculatorBillets(CalculatorBillets suivant) {
		this.setSuivant(suivant);
	}
	
	public void donnerBillets(Montant montant, List<Couple> proposition, EtatDistributeur etat) {
		if(this.suivant != null) {
			this.suivant.donnerBillets(montant, proposition, etat);
		}
	}

	public void setSuivant(CalculatorBillets suivant) {
		this.suivant = suivant;
	}
}
