package atm;

import java.util.List;

public class CalculatorBilletsGC10 extends CalculatorBillets {

	public CalculatorBilletsGC10(CalculatorBillets suivant) {
		super(suivant);
	}	

	public void donnerBillets(Montant montant, List<Couple> proposition, EtatDistributeur etat) {
		int nBillets = Math.min(montant.getMontant() / 10, etat.getNb10Disponible());
		montant.setMontant(montant.getMontant() - nBillets * 10);
		etat.setNb10Disponible(etat.getNb10Disponible() - nBillets);

		if(nBillets > 0) {
			proposition.add(new Couple(10, nBillets));
		}

		super.donnerBillets(montant, proposition, etat);
	}

}
