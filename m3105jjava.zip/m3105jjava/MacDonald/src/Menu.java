
public class Menu implements Cloneable {
	private Principal principal;
	private Accompagnement accompagnement;
	private Boisson boisson;

	private Menu(Principal principal, Accompagnement accompagnement, Boisson boisson) {
		this.principal = principal;
		this.accompagnement = accompagnement;
		this.boisson = boisson;
	}

	public static Menu initializeMenu(Principal principal, Accompagnement accompagnement, Boisson boisson) {
		return new Menu(principal, accompagnement, boisson);
	}

	public Principal getPrincipal() {
		return principal;
	}

	public void setPrincipal(Principal principal) {
		this.principal = principal;
	}

	public Accompagnement getAccompagnement() {
		return accompagnement;
	}

	public void setAccompagnement(Accompagnement accompagnement) {
		this.accompagnement = accompagnement;
	}

	public Boisson getBoisson() {
		return boisson;
	}

	public void setBoisson(Boisson boisson) {
		this.boisson = boisson;
	}

	@Override
	public String toString() {
		return "Menu [principal=" + principal + ", accompagnement=" + accompagnement + ", boisson=" + boisson + "]";
	}

	public Menu clone() {
		Menu clone = null;
		try {
			clone = (Menu) super.clone();
			clone.principal = this.principal;
			clone.accompagnement = this.accompagnement;
			clone.boisson = this.boisson;
		} catch(CloneNotSupportedException e) {
			e.printStackTrace();
		}

		return clone;
	}
}
