
public class Non extends OperandeUnaire {
	@Override
	public boolean isSatisfiable() {
		return !this.operande.isSatisfiable();
	}
	
	@Override
	public String toString() {
		return "!" + this.operande;
	}
	
}
