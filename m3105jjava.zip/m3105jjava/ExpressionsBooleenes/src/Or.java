public class Or extends OperandeBinaire {

	public Or() {
		super("+");
	}
	
	@Override
	public boolean isSatisfiable() {
		return this.operandeGauche.isSatisfiable() || this.operandeDroite.isSatisfiable();
	}

}