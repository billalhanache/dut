
public abstract class OperandeUnaire implements Satisfiable {
	protected Satisfiable operande;
	
	public void setOperande(Satisfiable operande) {
		this.operande = operande;
	}
	
	public Satisfiable getOperande() {
		return this.operande;
	}
}
