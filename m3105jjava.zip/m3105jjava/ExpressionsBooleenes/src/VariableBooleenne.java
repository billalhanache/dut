
public class VariableBooleenne implements Satisfiable {
	private String libelle;
	private String description;
	private boolean value;	
	
	public VariableBooleenne(String libelle, String description) {
		this.libelle = libelle;
		this.description = description;
	}
	
	public String getLibelle() {
		return this.libelle;
	}
	
	public String interpretation() {
		return (!this.value ? "non " : "") + this.description;
	}
	
	public boolean isSatisfiable() {
		return this.value;
	}
	
	public void fixerValeurDeVerite(boolean value) {
		this.value = value;
	}
	
	@Override
	public String toString() {
		return this.libelle;
	}
	
	
}
