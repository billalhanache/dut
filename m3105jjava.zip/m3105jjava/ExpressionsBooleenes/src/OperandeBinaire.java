
public abstract class OperandeBinaire implements Satisfiable {
	protected Satisfiable operandeGauche;
	protected Satisfiable operandeDroite;
	private String operator;
	
	public OperandeBinaire(String operator) {
		this.operator = operator;
	}
	
	public void setOperandeGauche(Satisfiable operandeGauche) {
		this.operandeGauche = operandeGauche;
	}
	
	public void setOperandeDroite(Satisfiable operandeDroite) {
		this.operandeDroite = operandeDroite;
	}
	
	public Satisfiable getOperandeGauche() {
		return this.operandeGauche;
	}
	
	public Satisfiable getOperandeDroite() {
		return this.operandeDroite;
	}
	
	@Override
	public String toString() {
		return "(" + this.operandeGauche + this.operator + this.operandeDroite + ")";
	}
}
