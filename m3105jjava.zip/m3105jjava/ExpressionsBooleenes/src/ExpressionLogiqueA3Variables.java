
public class ExpressionLogiqueA3Variables {
	private TableDesSymboles symboles;
	
	public Satisfiable constructionEpressionLogiqueA3Variables() {
		this.symboles = new TableDesSymboles();
		VariableBooleenne a = new VariableBooleenne("a", "Sonnerie");
		this.symboles.addVariable(a);
		VariableBooleenne b = new VariableBooleenne("b", "Décision de répondre");
		this.symboles.addVariable(b);
		VariableBooleenne c = new VariableBooleenne("c", "Décision d'appeler");
		this.symboles.addVariable(c);
		OperandeBinaire conjonctionGauche = new And();
		OperandeUnaire nonA= new Non();
		nonA.setOperande(a);
		conjonctionGauche.setOperandeGauche(nonA);
		conjonctionGauche.setOperandeDroite(c);
		OperandeBinaire conjonctionDroite= new And();
		conjonctionDroite.setOperandeGauche(a);
		conjonctionDroite.setOperandeDroite(b);
		OperandeBinaire décrocher= new Or();
		décrocher.setOperandeGauche(conjonctionGauche);
		décrocher.setOperandeDroite(conjonctionDroite);
		return décrocher;
	}
	
	public void quandDecrocherSonTelephone(Satisfiable décrocher) {
		for(int i= 0; i <= Math.pow(2,3) -1; i++) {
			this.symboles.fixerValeurDeVerite(i,3);
			if(décrocher.isSatisfiable()) {
				System.out.print("Je décroche mon téléphone quand : ");
				for(int j= 0; j< 3; j++) {
					System.out.print(this.symboles.interpretation(j));
					if(j< 2)System.out.print(" et ");
				}
				System.out.println();
			}
		}
	}
	
	public void quandNePasDecrocherSonTelephone(Satisfiable décrocher) {
		for(int i= 0; i<= Math.pow(2,3) -1; i++) {
			this.symboles.fixerValeurDeVerite(i,3);
			if(!décrocher.isSatisfiable()) {
				System.out.print("Je ne décroche pas mon téléphone quand : ");
				for(int j= 0; j< 3; j++) {
					System.out.print(this.symboles.interpretation(j));
					if(j< 2)System.out.print(" et ");
				}
				System.out.println();
			}
		}
	}
	
	public static void main(String[] args) {
		ExpressionLogiqueA3Variables unClient= new ExpressionLogiqueA3Variables();
		Satisfiable décrocher= unClient.constructionEpressionLogiqueA3Variables();
		System.out.print("Evaluation expression booléenne : ");
		System.out.println(décrocher);
		for(int i= 0; i<= Math.pow(2,3) -1; i++) {
			unClient.symboles.fixerValeurDeVerite(i,3);
			System.out.println(décrocher.isSatisfiable());
		}
		unClient.quandDecrocherSonTelephone(décrocher);
		unClient.quandNePasDecrocherSonTelephone(décrocher);
		
		Satisfiable expressionSortir = new ExpressionLogiqueA4Variables().constructionEpressionLogiqueA4Variables();
		System.out.println("Sortir: " + expressionSortir);
	}
}
