
public interface Satisfiable {
	public boolean isSatisfiable();
}
