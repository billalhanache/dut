import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class EntierTest {
	private Entier entierPositif;
	private Entier entierNul;
	private Entier entierNegatif;
	
	@Before
	public void setUp() throws Exception {
		this.entierPositif = new Entier(7);
		this.entierNul = new Entier(0);
		this.entierNegatif = new Entier(-7);
	}

	@After
	public void tearDown() throws Exception {
		this.entierPositif = null;
		this.entierNul = null;
		this.entierNegatif = null;
	}

	@Test
	public void testPositif() {
		assertEquals(7, this.entierPositif.evaluate());
	}
	
	@Test
	public void testNul() {
		assertEquals(0, this.entierNul.evaluate());
	}
	
	@Test
	public void testNegatif() {
		assertEquals(-7, this.entierNegatif.evaluate());
	}

}
