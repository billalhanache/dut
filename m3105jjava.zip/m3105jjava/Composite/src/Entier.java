
public class Entier extends Expression {
	private int valeur;
	public Entier(int valeur) {
		this.valeur = valeur;
	}

	public int evaluate() {
		return this.valeur;
	}
}
