import java.util.ArrayList;
import java.util.List;

public abstract class ExpressionComposite extends Expression {
	protected List<Expression> children;
	
	public ExpressionComposite() {
		this.children = new ArrayList<>();
	}
	
	public void add(Expression expression) {
		this.children.add(expression);
	}
	
	public abstract int evaluate();
}
