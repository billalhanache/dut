import java.util.Iterator;
import java.util.List;

public abstract class Filtre {
	private Filtre next;

	public void appliquerFiltre(List<UserStory> userStories) {
		Iterator<UserStory> it = userStories.iterator();
		while (it.hasNext()) {
			UserStory userStory = it.next();
			if  (this.userStoryAEnlever(userStory))
				it.remove();
		}
		
		if(this.next != null) {
			this.next.appliquerFiltre(userStories);
		}
	}
	
	public abstract boolean userStoryAEnlever(UserStory userStory);
	
	public void setSuivant(Filtre next) {
		this.next = next;
	}
}
