public class FiltreBusinessValue extends Filtre {
	private int businessValue;
	
	public static final int PAS_BEAUCOUP = 10, PAS_ASSEZ = 30;
	
	public FiltreBusinessValue(int businessValue) {
		this.businessValue = businessValue;
	}
	
	@Override
	public boolean userStoryAEnlever(UserStory userStory) {
		return userStory.getBusinessValueEnEuro() < this.businessValue;
	}
}
