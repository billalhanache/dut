package competences;

public class CompetencesEtat extends Competences {

	public CompetencesEtat() {
		super("Etat");
		this.competences.put("Formation Professionnelle et Apprentissage","D�finition de la politique nationale et mise en �uvre pour certains publics");
		this.competences.put("Enseignement","Universit�s (b�timents, personnel), Politique �ducative");
		this.competences.put("Culture et vie sociale","patrimoine, �ducation, cr�ation, biblioth�ques, mus�es, archives");
		this.competences.put("sports et loisirs","formation, subventions, tourisme");
		this.competences.put("Action sociale et m�dico-sociale","allocation d�adulte handicap�, centre d�h�bergement et de r�insertion sociale");
		this.competences.put("Urbanisme","projet d�int�r�t g�n�ral, op�rations d�int�r�t national, directive territoriale d�am�nagement");
		this.competences.put("Am�nagement du territoir","politique d'am�nagement du territoir, contrat de projet �tat/r�gion");
		this.competences.put("Environnement","Espaces naturels, Parcs Nationaux, sch�ma d�am�nagement et de gestion des eaux, �nergie");
		this.competences.put("Grands �quipements","Ports autonomes et d�int�r�t national, Voies navigables, A�rodromes");
		this.competences.put("D�veloppement �conomique","Politique �conomique");
		this.competences.put("S�curit�","Police g�n�rale et polices sp�ciales");
	}
}
