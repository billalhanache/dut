package chaine;

public class Client {
	private HandlerA a;
	private HandlerB b;
	private HandlerC c;

	public Client() {
		this.a = new HandlerA();
		this.b = new HandlerB();
		this.c = new HandlerC();
	}

	public static void main(String[] args) {
		Client c = new Client();

		c.handleABC();
		System.out.println("---------------------");
		c.handleCBA();
	}

	public void handleABC() {
		this.clear();

		this.a.setNext(b);
		this.b.setNext(c);

		this.a.handle();
	}

	public void handleCBA() {
		this.clear();

		this.c.setNext(b);
		this.b.setNext(a);

		this.c.handle();
	}

	private void clear() {
		this.a.setNext(null);
		this.b.setNext(null);
		this.c.setNext(null);
	}
}
