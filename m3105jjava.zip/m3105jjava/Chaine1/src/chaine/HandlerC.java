package chaine;

public class HandlerC extends Handler {
	public void handle() {
		System.out.println("Handled by C !");
		
		super.handle();
	}
}
