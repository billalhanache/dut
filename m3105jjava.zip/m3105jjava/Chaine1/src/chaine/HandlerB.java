package chaine;

public class HandlerB extends Handler {
	public void handle() {
		System.out.println("Handled by B !");
		
		super.handle();
	}
}
