package start;

public class ExpressionsDuSud extends Expressions {

	public ExpressionsDuSud() {
		super("Expressions du Sud ...");
		this.expressions.add(new Entry("Se gaver", "ce qui veut dire exceller, si vous d�ambulez du c�t� de N�mes."));
		this.expressions.add(new Entry("Tarpin", "le trop ou tr�s marseillais. C'est tarpin bon."));
		this.expressions.add(new Entry("Ca p�gue", "�a colle, tout simplement."));
		this.expressions.add(new Entry("Ca m'espante", "autrement dit, c'est surprenant."));
		this.expressions.add(new Entry("Ca m'enfade", "A comprendre tu m'�nerves."));
		this.expressions.add(new Entry("Peuch�re", "mon pauvre ou ma pauvre."));
		this.expressions.add(new Entry("Roum�guer", "signifie r�ler."));
		this.expressions.add(new Entry("�tre ensuqu�", "veut dire �tre endormi, assoupi, mou de la chique."));
		this.expressions.add(new Entry("Caguer", "ou plus commun�ment chier, d�f�quer."));
		this.expressions.add(new Entry("�tre quich�", "signifie �tre serr�."));
		this.expressions.add(new Entry("Boudiou", "le Mon Dieu du sudiste branch�."));
	}

}
