package start;

import java.util.LinkedList;
import java.util.List;

public abstract class Expressions {
	private String name;
	protected List<Entry> expressions;
	private Expressions next;
	
	public Expressions(String name) {
		this.name = name;
		this.expressions = new LinkedList<>();
	}
	
	public void setSuivant(Expressions next) {
		this.next = next;
	}
	
	public void rechercherExpression(String lettres) {
		System.out.println(this.name);
		for (Entry e:this.expressions) {
			String name = e.getName().toLowerCase();
			if (name.contains(lettres)) {
				System.out.println(e.getName() + " : " + e.getDefinition());
			}				
		}
		
		if(this.next != null) {
			this.next.rechercherExpression(lettres);
		}
	}
}
