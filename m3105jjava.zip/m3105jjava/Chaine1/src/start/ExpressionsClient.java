package start;

public class ExpressionsClient {
	public void rechercherEtEditerDuPlusPresAuPlusLoin(String lettres) {
		System.out.println("Recherche des expressions contenant " + lettres);
		ExpressionsToulousaines t = new ExpressionsToulousaines();
		ExpressionsDuSud s = new ExpressionsDuSud();
		ExpressionsDeLorraine l = new ExpressionsDeLorraine();
		
		t.setSuivant(s);
		s.setSuivant(l);
		
		t.rechercherExpression(lettres);
	}
	
	public void rechercherEtEditerDuPlusLoinAuPlusPres(String lettres) {
		System.out.println("Recherche des expressions contenant " + lettres);
		
		ExpressionsToulousaines t = new ExpressionsToulousaines();
		ExpressionsDuSud s = new ExpressionsDuSud();
		ExpressionsDeLorraine l = new ExpressionsDeLorraine();
		
		l.setSuivant(s);
		s.setSuivant(t);
		
		l.rechercherExpression(lettres);
	}
	
	public static void main(String[] args) {
		ExpressionsClient expressions = new ExpressionsClient();
		expressions.rechercherEtEditerDuPlusPresAuPlusLoin("abcd");
		System.out.println();
		expressions.rechercherEtEditerDuPlusPresAuPlusLoin("tarpin");
		System.out.println();
		expressions.rechercherEtEditerDuPlusPresAuPlusLoin("cag");
		System.out.println();
		expressions.rechercherEtEditerDuPlusLoinAuPlusPres("ca");
	}

}
