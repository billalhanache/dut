package start;

public class ExpressionsToulousaines extends Expressions {

	public ExpressionsToulousaines() {
		super("Expressions Toulousaines ...");
		this.expressions.add(new Entry("Aimable", "gentil, agr�able. Elle est aimable, la ma�tresse ?"));
		this.expressions.add(new Entry("Bader", "rester bouche b�e devant. Ta soeur, elle arr�te pas de le bader."));
		this.expressions.add(new Entry("Banane", "mauvaise note. C'est la premi�re fois de l'ann�e que je prends pas une banane."));
		this.expressions.add(new Entry("Cagade",  "chiure, �chec. �a a �t� une cagade totale. De l'occitan cagada, chi�e."));
		this.expressions.add(new Entry("Cagnasse", "grosse chaleur, canicule, celle qui co�te des litres de sueur � chaque mouvement."));
		this.expressions.add(new Entry("Caguer", "Tu vas pas nous en caguer une pendule ! Il nous fait caguer, l'autre ! De l'occitan cagar, chier."));
		this.expressions.add(new Entry("D�ner", "repas de midi, d�je�ner. Venez vers midi pour d�ner ! De l'occitan dinnar."));
		this.expressions.add(new Entry("Empapaouter", "arnaquer, rouler. Je te l'ai empapaout� vite fait ! De l'occitan empapautar."));
		this.expressions.add(new Entry("Franchimand", "fran�ais du nord (de la Loire). Le probl�me avec les franchimands, c'est qu'ils se croient plus intelligents que toi."));
		this.expressions.add(new Entry("Garnir", "remplir un formulaire. Vous me garnissez encore cette feuille, et ce sera bon."));
		this.expressions.add(new Entry("Patac", "Il s'est pris un pat�c qui l'a ensuqu�*, et il s'est esplatern�."));
		this.expressions.add(new Entry("Que", "car, parce que. Couvre-toi que tu vas avoir froid. De l'occitan que, car."));
		this.expressions.add(new Entry("Pigne", "fruit de conif�re. Prends des pignes pour lancer le feu."));
		this.expressions.add(new Entry("Rien que", "Il est venu rien que lui. Rien que ? Oui, rien que lui !"));
		this.expressions.add(new Entry("Tavanard", "objet qui boudonne fort en allant vite. La moto, elle m'a d�pass� comme un tavanard."));
	}

}
