
public class ExpressionsDuSud extends Expressions {

	public ExpressionsDuSud(Expressions suivant) {
		super("Expressions du Sud...", suivant);
		
		this.expressions.add(new Entry("Se gaver", "ce qui veut dire exceller, si vous deambulez du cote de Nimes."));
		this.expressions.add(new Entry("Tarpin", "le trop ou tres marseillais. C'est tarpin bon."));
		this.expressions.add(new Entry("Ca pegue", "ca colle, tout simplement."));
		this.expressions.add(new Entry("Ca m'espante", "autrement dit, c'est surprenant."));
		this.expressions.add(new Entry("Ca m'enfade", "A comprendre tu m'enerves."));
		this.expressions.add(new Entry("Peuchere", "mon pauvre ou ma pauvre."));
		this.expressions.add(new Entry("Roumiguer", "signifie raler."));
		this.expressions.add(new Entry("etre ensuque", "veut dire etre endormi, assoupi, mou de la chique."));
		this.expressions.add(new Entry("Caguer", "ou plus communement chier, defequer."));
		this.expressions.add(new Entry("etre quiche", "signifie etre serre."));
		this.expressions.add(new Entry("Boudiou", "le Mon Dieu du sudiste branche."));
	}
	
	public ExpressionsDuSud() {
		this(null);
	}

}
