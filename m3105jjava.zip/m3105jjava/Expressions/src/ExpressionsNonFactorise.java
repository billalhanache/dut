

import java.util.LinkedList;

public class ExpressionsNonFactorise {
	
	private LinkedList<Entry> expressionsToulousaines;
	private LinkedList<Entry> expressionsDuSud;
	private LinkedList<Entry> expressionsDeLorraine;
	
	public ExpressionsNonFactorise() {
		// creation des expressions toulousaines
		this.expressionsToulousaines = new LinkedList<Entry>();
		this.expressionsToulousaines.add(new Entry("Aimable", "gentil, agreable. Elle est aimable, la maitresse ?"));
		this.expressionsToulousaines.add(new Entry("Bader", "rester bouche bee devant. Ta soeur, elle arrete pas de le bader."));
		this.expressionsToulousaines.add(new Entry("Banane", "mauvaise note. C'est la premiere fois de l'annee que je prends pas une banane."));
		this.expressionsToulousaines.add(new Entry("Cagade",  "chiure, echec. ca a ete une cagade totale. De l'occitan cagada, chiee."));
		this.expressionsToulousaines.add(new Entry("Cagnasse", "grosse chaleur, canicule, celle qui coute des litres de sueur a chaque mouvement."));
		this.expressionsToulousaines.add(new Entry("Caguer", "Tu vas pas nous en caguer une pendule ! Il nous fait caguer, l'autre ! De l'occitan cagar, chier."));
		this.expressionsToulousaines.add(new Entry("Diner", "repas de midi, dejeuner. Venez vers midi pour diner ! De l'occitan dinnar."));
		this.expressionsToulousaines.add(new Entry("Empapaouter", "arnaquer, rouler. Je te l'ai empapaoute vite fait ! De l'occitan empapautar."));
		this.expressionsToulousaines.add(new Entry("Franchimand", "francais du nord (de la Loire). Le probleme avec les franchimands, c'est qu'ils se croient plus intelligents que toi."));
		this.expressionsToulousaines.add(new Entry("Garnir", "remplir un formulaire. Vous me garnissez encore cette feuille, et ce sera bon."));
		this.expressionsToulousaines.add(new Entry("Patac", "Il s'est pris un patac qui l'a ensuque*, et il s'est esplaterne."));
		this.expressionsToulousaines.add(new Entry("Que", "car, parce que. Couvre-toi que tu vas avoir froid. De l'occitan que, car."));
		this.expressionsToulousaines.add(new Entry("Pigne", "fruit de conifere. Prends des pignes pour lancer le feu."));
		this.expressionsToulousaines.add(new Entry("Rien que", "Il est venu rien que lui. Rien que ? Oui, rien que lui !"));
		this.expressionsToulousaines.add(new Entry("Tavanard", "objet qui boudonne fort en allant vite. La moto, elle m'a depasse comme un tavanard."));
		
		// creation des expressions du sud
		this.expressionsDuSud = new LinkedList<Entry>();
		this.expressionsDuSud.add(new Entry("Se gaver", "ce qui veut dire exceller, si vous deambulez du cote de Nimes."));
		this.expressionsDuSud.add(new Entry("Tarpin", "le trop ou tres marseillais. C'est tarpin bon."));
		this.expressionsDuSud.add(new Entry("Ca pegue", "ca colle, tout simplement."));
		this.expressionsDuSud.add(new Entry("Ca m'espante", "autrement dit, c'est surprenant."));
		this.expressionsDuSud.add(new Entry("Ca m'enfade", "A comprendre tu m'enerves."));
		this.expressionsDuSud.add(new Entry("Peuchere", "mon pauvre ou ma pauvre."));
		this.expressionsDuSud.add(new Entry("Roumiguer", "signifie raler."));
		this.expressionsDuSud.add(new Entry("etre ensuque", "veut dire etre endormi, assoupi, mou de la chique."));
		this.expressionsDuSud.add(new Entry("Caguer", "ou plus communement chier, defequer."));
		this.expressionsDuSud.add(new Entry("etre quiche", "signifie etre serre."));
		this.expressionsDuSud.add(new Entry("Boudiou", "le Mon Dieu du sudiste branche."));
		
		// cr�ation des expressions lorraines
		this.expressionsDeLorraine = new LinkedList<Entry>();
		this.expressionsDeLorraine.add(new Entry("Oh l'autre !",  "Tu rigoles !"));
		this.expressionsDeLorraine.add(new Entry("Tu viens avec ?", "Viens-tu avec nous ?"));
		this.expressionsDeLorraine.add(new Entry("Brimbelle", "Myrtille"));
		this.expressionsDeLorraine.add(new Entry("Oh l'autre !",  "Tu rigoles !"));
		this.expressionsDeLorraine.add(new Entry("Beuille", "un bleu"));
		this.expressionsDeLorraine.add(new Entry("Faire bleu", "secher les cours"));
		this.expressionsDeLorraine.add(new Entry("Ca caille", "Il fait froid"));
		this.expressionsDeLorraine.add(new Entry("Chlass","Couteau"));
		this.expressionsDeLorraine.add(new Entry("Clanche", "La poignee de porte"));
		this.expressionsDeLorraine.add(new Entry("Ca gehtas ?", "Ca va bien ?"));
		this.expressionsDeLorraine.add(new Entry("Entre midi", "Entre midi et 14h"));
		this.expressionsDeLorraine.add(new Entry("Flot", "noeud"));
		this.expressionsDeLorraine.add(new Entry("Nareux", "Personne qui n'aime pas boire apres quelqu'un dans la meme bouteille"));
		this.expressionsDeLorraine.add(new Entry("Schnek", "Pain aux raisins"));
		this.expressionsDeLorraine.add(new Entry("Schlapp", "Savate"));
		this.expressionsDeLorraine.add(new Entry("Schlouc", "Une gorgee"));		
	}
	
	public void rechercherEtEditerDuPlusPresAuPlusLoin(String lettres) {
		System.out.println("Recherche des expressions contenant " + lettres);
		
		System.out.println("Expressions Toulousaines...");
		for (Entry e:this.expressionsToulousaines) {
			String name = e.getName().toLowerCase();
			if (name.contains(lettres)) {
				System.out.println(e.getName() + " : " + e.getDefinition());
			}				
		}
		
		System.out.println("Expressions du Sud...");
		for (Entry e:this.expressionsDuSud) {
			String name = e.getName().toLowerCase();
			if (name.contains(lettres)) {
				System.out.println(e.getName() + " : " + e.getDefinition());
			}				
		}
		
		System.out.println("Expressions de Lorraine...");
		for (Entry e:this.expressionsDeLorraine) {
			String name = e.getName().toLowerCase();
			if (name.contains(lettres)) {
				System.out.println(e.getName() + " : " + e.getDefinition());
			}				
		}
	}
	
	public void rechercherEtEditerDuPlusLoinAuPlusPres(String lettres) {
		System.out.println("Recherche des expressions contenant " + lettres);
		
		System.out.println("Expressions de Lorraine...");
		for (Entry e:this.expressionsDeLorraine) {
			String name = e.getName().toLowerCase();
			if (name.contains(lettres)) {
				System.out.println(e.getName() + " : " + e.getDefinition());
			}				
		}
		
		System.out.println("Expressions du Sud...");
		for (Entry e:this.expressionsDuSud) {
			String name = e.getName().toLowerCase();
			if (name.contains(lettres)) {
				System.out.println(e.getName() + " : " + e.getDefinition());
			}				
		}
		
		System.out.println("Expressions Toulousaines...");
		for (Entry e:this.expressionsToulousaines) {
			String name = e.getName().toLowerCase();
			if (name.contains(lettres)) {
				System.out.println(e.getName() + " : " + e.getDefinition());
			}				
		}
	}
	
	public static void main(String[] args) {
		ExpressionsNonFactorise expressions = new ExpressionsNonFactorise();
		expressions.rechercherEtEditerDuPlusPresAuPlusLoin("abcd");
		System.out.println();
		expressions.rechercherEtEditerDuPlusPresAuPlusLoin("tarpin");
		System.out.println();
		expressions.rechercherEtEditerDuPlusPresAuPlusLoin("cag");
		System.out.println();
		expressions.rechercherEtEditerDuPlusLoinAuPlusPres("ca");
	}

}
