
public class ExpressionsClient {

	public ExpressionsClient() {
		// TODO Auto-generated constructor stub
	}
	
	public void rechercherEtEditerDuPlusPresAuPlusLoin(String lettres) {
		System.out.println("Recherche des expressions contenant " + lettres);
		
		new ExpressionsToulousaines(new ExpressionsDuSud(new ExpressionsDeLorraine())).rechercherExpressions(lettres);;
	}
	
	public void rechercherEtEditerDuPlusLoinAuPlusPres(String lettres) {
		System.out.println("Recherche des expressions contenant " + lettres);
		
		new ExpressionsDeLorraine(new ExpressionsDuSud(new ExpressionsToulousaines())).rechercherExpressions(lettres);
	}

	public static void main(String[] args) {
		ExpressionsClient client = new ExpressionsClient();
		
		client.rechercherEtEditerDuPlusPresAuPlusLoin("abcd");
		System.out.println();
		client.rechercherEtEditerDuPlusPresAuPlusLoin("tarpin");
		System.out.println();
		client.rechercherEtEditerDuPlusPresAuPlusLoin("cag");
		System.out.println();
		client.rechercherEtEditerDuPlusLoinAuPlusPres("ca");
	}

}
