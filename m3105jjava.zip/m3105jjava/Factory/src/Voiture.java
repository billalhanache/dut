
public class Voiture extends Vehicule {
	public String describe() {
		return "Je suis une voiture";
	}
}
