
public class VehiculeFactory {
	public static final int VEHICULE_VOITURE = 1;
	public static final int VEHICULE_MOTO = 2;
	
	public Vehicule getVehicule(int vehicule) {
		switch(vehicule) {
		case VEHICULE_VOITURE:
			return new Voiture();
		case VEHICULE_MOTO:
			return new Moto();
		default:
			throw new IllegalArgumentException("V�hicule inconnu");
		}
	}
}
