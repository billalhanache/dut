
public abstract class Vehicule {
	public abstract String describe();
}
