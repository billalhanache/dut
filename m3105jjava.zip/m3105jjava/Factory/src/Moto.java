public class Moto extends Vehicule {
	public String describe() {
		return "Je suis une moto";
	}
}
