
public class FabriqueADureeEnHeuresMinutesSecondes implements FabriqueADuree {

	@Override
	public Duree create(int heures, int minutes, int secondes) {
		return new DureeEnHeuresMinutesSecondes(heures, minutes, secondes);
	}
}
