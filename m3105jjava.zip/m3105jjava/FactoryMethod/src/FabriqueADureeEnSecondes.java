
public class FabriqueADureeEnSecondes implements FabriqueADuree {
	@Override
	public Duree create(int heures, int minutes, int secondes) {
		return new DureeEnSecondes(heures, minutes, secondes);
	}
}
