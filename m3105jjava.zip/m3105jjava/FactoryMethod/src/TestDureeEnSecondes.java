import org.junit.Before;


public class TestDureeEnSecondes extends TestDuree {
	@Before
	public void setUp() {
		this.factory = new FabriqueADureeEnSecondes();
	}
}
