import java.util.ArrayList;
import java.util.List;

public class Responsable {
	private String nom;
	private String prenom;
	private String initiales;
	private List<TacheAbstraite> taches;
	
	public static Responsable FS = new Responsable("Francois", "Sommier", "FS");
	public static Responsable DE = new Responsable("Damien", "Esperanza", "DE");
	public static Responsable AN = new Responsable("Alice", "Nevers", "NE");
	public static Responsable CS = new Responsable("Carole", "Salle", "CE");
	public static Responsable RH = new Responsable("Robin", "Haltere", "RH");
	public static Responsable DV = new Responsable("Damien", "Vodka", "DV");
	public static Responsable CP = new Responsable("Collin", "Perez", "CP");
	public static Responsable XP = new Responsable("Xavier", "Poisson", "XP");
	
	public String getNom() {
		return nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public String getInitiales() {
		return initiales;
	}

	public List<TacheAbstraite> getTaches() {
		return taches;
	}

	public Responsable(String nom, String prenom, String initiales) {
		this.nom = nom;
		this.prenom = prenom;
		this.initiales = initiales;
		this.taches = new ArrayList<>();
	}
}
