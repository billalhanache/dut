
public class Delivrable extends TacheAbstraite {
	private double duree;
	
	public Delivrable(String nom, Responsable responsable, double duree) {
		super(nom, responsable);
		this.duree = duree;
	}

	@Override
	public double getTempsRequis() {
		return this.duree;
	}

	@Override
	public String toString(String nbEspaces) {
		String result = nbEspaces + this.nom + " (d)";
		result = result  + " ".repeat(50 - result.length()) + "(" + this.responsable.getInitiales() + ")";
		return result;
	}
}
