
public abstract class TacheAbstraite {
	protected String nom;
	protected Responsable responsable;
	
	public TacheAbstraite(String nom, Responsable responsable) {
		this.nom = nom;
		this.responsable = responsable;
	}
	
	public abstract double getTempsRequis();
	public abstract String toString(String nbEspaces);
}
