package afpIncomplet;

public class MMSSubscriber extends SMSSubscriber implements Subscriber {
	private NewsImage derniereNews;
	public MMSSubscriber(String phoneNumber) {
		super(phoneNumber);
	}
	
	public String getDernierMessage() {
		return this.derniereNews.toString();
	}

	@Override
	public void update(Publisher s) {
		if(!(s instanceof AgencePresseWithImage)) return;
		AgencePresseWithImage afp = (AgencePresseWithImage) s;
		this.derniereNews = afp.getLatestNews();
		System.out.println("Envoi MMS à " + this.phoneNumber + " " + this.derniereNews);
	}
}
