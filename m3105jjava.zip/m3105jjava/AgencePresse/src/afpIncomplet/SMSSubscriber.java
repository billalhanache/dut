package afpIncomplet;

public class SMSSubscriber implements Subscriber {

	protected String phoneNumber;
	private String dernierMessage;
	
	public SMSSubscriber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	public String getDernierMessage() {
		return this.dernierMessage;
	}

	@Override
	public void update(Publisher s) {
		AgencePresse afp = (AgencePresse) s;
		this.dernierMessage = afp.getLatestNews();
		System.out.println("Envoi SMS à " + this.phoneNumber + " " + this.dernierMessage);
	}

}
