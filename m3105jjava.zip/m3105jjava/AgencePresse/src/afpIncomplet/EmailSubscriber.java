package afpIncomplet;

public class EmailSubscriber implements Subscriber {

	private String emailAdress;
	private String dernierMessage;
	
	public EmailSubscriber(String emailAdress) {
		this.emailAdress = emailAdress;
	}

	public String getDernierMessage() {
		return this.dernierMessage;
	}
	
	@Override
	public void update(Publisher s) {
		AgencePresse afp = (AgencePresse) s;
		this.dernierMessage = afp.getLatestNews();
		System.out.println("Envoi email a " + this.emailAdress + " " + this.dernierMessage);
	}

}
