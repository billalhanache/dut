package afpIncomplet;

import java.util.Deque;
import java.util.LinkedList;

public class AgencePresseWithImage extends Publisher {
	protected Deque<NewsImage> nouvelles;
	
	public AgencePresseWithImage() {
		this.nouvelles = new LinkedList<>();
	}
	
	public NewsImage getLatestNews(){
		return this.nouvelles.getLast();
	}
	
	public void addNews(String news, String image){
		if (this.nouvelles.size() == 100)
			this.nouvelles.removeFirst();
		this.nouvelles.addLast(new NewsImage(news, image));
		this.notifyObservers();
	}

}
