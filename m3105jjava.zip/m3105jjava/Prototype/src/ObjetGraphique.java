
public abstract class ObjetGraphique implements Cloneable {
	private double coordX;
	private double coordY;
	
	public ObjetGraphique(double coordX, double coordY) {
		this.coordX = coordX;
		this.coordY = coordY;
	}
	
	public void translater(double dx, double dy) {
		this.coordX += dx;
		this.coordY += dy;
	}

	@Override
	public String toString() {
		return "ObjetGraphique [coordX=" + coordX + ", coordY=" + coordY + "]";
	}
	
	public ObjetGraphique clone() {
		ObjetGraphique clone = null;
		try {
			clone = (ObjetGraphique) super.clone();
			clone.coordX = this.coordX;
			clone.coordY = this.coordY;
		} catch(CloneNotSupportedException e) {
			e.printStackTrace();
		}
		return clone;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ObjetGraphique other = (ObjetGraphique) obj;
		if (Double.doubleToLongBits(coordX) != Double.doubleToLongBits(other.coordX))
			return false;
		if (Double.doubleToLongBits(coordY) != Double.doubleToLongBits(other.coordY))
			return false;
		return true;
	}
}
