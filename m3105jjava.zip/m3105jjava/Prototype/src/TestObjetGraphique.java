
public class TestObjetGraphique {
	public static void main(String[] args) {
		Immeuble im1 = new Immeuble(1,10,"blanc",23,5);
		
		System.out.println("Premier immeuble: " + im1);
	}

}
