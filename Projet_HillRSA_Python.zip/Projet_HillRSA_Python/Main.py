# -*- coding: utf-8 -*-

import ChiffrementHillRSA as m

Bob = m.Destinataire(18923,1261)
Bob.b = 5797
Alice = m.Expediteur(31313,4913)
matrice_A = [[20,14,0,25,13],[22,27,0,11,2],[0,0,30,0,0],[7,19,0,23,10],[18,13,0,8,23]]
Alice.setMatrice(matrice_A)
Alice.b = 6497
print("Matrice A =")
m.Message.affichageMatrice(Alice.matrice_A)

print("Matrice Acodée =")
Bob.matrice_A_codée = Alice.chiffrageMatriceCodage(Bob.a,Bob.n) 
m.Message.affichageMatrice(Bob.matrice_A_codée)

texte = " diviser pour regner, la maxime est ancienne._elle fut d un tyran, ce n est donc pas la mienne._vous unir est mon voeu; j aime la liberte;_et si j ai quelque volonte, c est que chacun la fasse sienne."

print("Message clair : \n",m.Message.remplaceSautAlaLigne(texte),"\n")
texte_codé = Alice.coderMessage(texte)
print("Message codé : \n",m.Message.remplaceSautAlaLigne(texte_codé),"\n")

Alice.setSignature(Bob.a,Bob.n)
print("Signature donnée par Alice :",Alice.sign,"\n")

print("Matrice déchiffrée par Bob =")
Bob.dechiffrageMatrice()
m.Message.affichageMatrice(Bob.matrice_A) 

#Verification de la signature
print("Bob trouve que :")
if(Bob.verifSign(Alice)):
    print("L'expéditeur est bien Alice.\n")
else:
    print("C'est un mauvais expéditeur\n")

print("Message décodé par Bob :\n",m.Message.remplaceSautAlaLigne(Bob.decoderMessage(texte_codé)))
        