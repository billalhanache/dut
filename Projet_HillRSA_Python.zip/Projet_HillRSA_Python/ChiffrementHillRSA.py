


class Message:
    
    NB_LETTRE = 31  
    alphabet = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r',
                's','t','u','v','w','x','y','z',',',';','.',' ','_']
    @staticmethod
    def remplaceSautAlaLigne(mes):
        liste = list(mes)
        for i in range(len(mes)):
            if(liste[i]=='_'):
                liste[i]='\n'
            elif(liste[i]=='\n'):
                liste[i]=='_'
        return ''.join(liste)
    
    @staticmethod
    def tableauToMessage(tab):
        chaine = ""
        for i in range(len(tab)):
            chaine += tab[i]
        return chaine

    @staticmethod
    #On met le message sous forme numéric
    def messageAlphaToMessageNum(self,message):
        message_num = {}
        for i in range(len(message)):
            for j in range(len(self.alphabet)):
                if(message[i]==self.alphabet[j]):
                    message_num[i] = j
                # elif(j == 30 and message_num[i]==):
                #     print("Le caractere "+message[i]+" n° "+str(i)+ " n'a pas été reconnue")
                #     return 0
        return message_num
    
    @staticmethod
    def affichageMatrice(A):
        for i in range(len(A)):
            print(A[i])
        print("\n")
        return 0
    

    @staticmethod
    #On dechiffre le message
    def messageNumToMessageAlpha(self,messageNum):
        message_dec = []
        for i in range(len(messageNum)):
            message_dec.append(self.alphabet[messageNum[i]])
        return message_dec
    
    @staticmethod
    #On divise le message chiffré en paquet de m longueur
    def diviserListeEnPaquetListe(m,mes):
        mes_div=[]
        paquet={}
        nombrePoint = m-len(mes)%m
        if(nombrePoint==m):
            nombrePoint=0
        for i in range(len(mes)):
            if(i%m==0 and i > 0):
                mes_div.append(paquet)
                paquet ={}
            paquet[i%m]=mes[i]
            if(i == len(mes)-1):
                while nombrePoint > 0:
                    i+=1
                    nombrePoint -= 1
                    paquet[i%m] = 28
        mes_div.append(paquet)
        return mes_div
    
    def rediviserListeEnPaquetListe(m,mes):
        mes_div=[]
        paquet={}
        nombrePoint = m-len(mes)%m
        for i in range(len(mes)):
            if(i%m==0 and i > 0):
                mes_div.append(paquet)
                paquet ={}
            paquet[i%m]=mes[i]
        mes_div.append(paquet)
        return mes_div
    
    @staticmethod
    def reformerPaquet(paquets):
        paquet = []
        for i in range(len(paquets)):
            for j in range(len(paquets[i])):
                paquet.append(paquets[i][j])
        return paquet

    
class Destinataire:
    
    p = 0
    q = 0
    a = 0
    n = 0
    b = 0
    matrice_A_codée = 0
    matrice_A = 0
    
    def __init__(self,n,a):
        self.a = a
        self.n = n
    
    def verifSign(self,Dest):
        max = self.matrice_A[0][0]
        nbligne = len(self.matrice_A)
        #On cherche le max de la matrice connu par le destinataire
        for i in range(nbligne):
            for j in range(nbligne):
                if(self.matrice_A[i][j]>max):
                    max = self.matrice_A[i][j]
    
        zBob = Dest.sign**(self.b) % self.n
        zBob = zBob%Dest.n
        zBob = ((zBob**Dest.a)%Dest.n)
        if(zBob == max):
            return True
        else:
            return False
    
    def coderPaquet(self,paquet):
        if(len(self.matrice_A)!=len(paquet)):
            print("Le paquet n'a pas la bonne taille pour être multiplié par la matrice")
            return 0
        paquet_codé = []
        #ligne de la matrice
        for i in range(len(self.matrice_A)):
            n = 0
            #colonne de la matrice
            for j in range(len(self.matrice_A)):
                n+=paquet[j]*(self.matrice_A[i][j])
            paquet_codé.append(n%(Message.NB_LETTRE))
        return paquet_codé
    
    def coderEnsemblePaquets(self,ens_paquet):
        ens_paquet_codé = []
        for i in range (len(ens_paquet)):
            paquetAct = self.coderPaquet(ens_paquet[i])
            ens_paquet_codé.append(paquetAct)
        return ens_paquet_codé
    
    
    def dechiffrageMatrice(self):
        aprime = []
        ligne = []
        nbligne = len(self.matrice_A_codée)
        for i in range(nbligne):
            for j in range(nbligne):
                ligne.append((self.matrice_A_codée[i][j]**self.b)%self.n)
            aprime.append(ligne)
            ligne = []
        self.matrice_A = aprime
        return aprime
    
    def decoderMessage(self,message):
        message_chiffré = Message.messageAlphaToMessageNum(Message, message)
        paquets = Message.rediviserListeEnPaquetListe(len(self.matrice_A),message_chiffré)
        paquets_codé = self.coderEnsemblePaquets(paquets)
        paquets_codé_alpha = Message.messageNumToMessageAlpha(Message, Message.reformerPaquet(paquets_codé))
        return Message.tableauToMessage(paquets_codé_alpha)
    
        
            
    
    

class Expediteur:
    
    p = 0
    q = 0
    a = 0
    n = 0
    b = 0
    sign = 0
    matrice_A = 0
    
    def __init__(self,n,a):
        self.a = a
        self.n = n
        
    def setMatrice(self,matrice):
        self.matrice_A = matrice
        
    def maxMatrice(self):
        max = self.matrice_A[0][0]
        nbligne = len(self.matrice_A)
        
        #on cherche α = max(A)
        for i in range(nbligne):
            for j in range(nbligne):
                if(self.matrice_A[i][j]>max):
                    max = self.matrice_A[i][j]
        return max
    
    def coderPaquet(self,paquet):
        if(len(self.matrice_A)!=len(paquet)):
            print("Le paquet n'a pas la bonne taille pour être multiplié par la matrice")
            return 0
        paquet_codé = []
        #ligne de la matrice
        for i in range(len(self.matrice_A)):
            n = 0
            #colonne de la matrice
            for j in range(len(self.matrice_A)):
                n+=paquet[j]*(self.matrice_A[i][j])
            paquet_codé.append(n%(Message.NB_LETTRE))
        return paquet_codé
        
    def coderEnsemblePaquets(self,ens_paquet):
        ens_paquet_codé = []
        for i in range (len(ens_paquet)):
            paquetAct = self.coderPaquet(ens_paquet[i])
            ens_paquet_codé.append(paquetAct)
        
        return ens_paquet_codé
    
    def coderMessage(self,message):
        message_chiffré = Message.messageAlphaToMessageNum(Message, message)
        paquets = Message.diviserListeEnPaquetListe(len(self.matrice_A),message_chiffré)
        paquets_codé = self.coderEnsemblePaquets(paquets)
        paquets_codé_alpha = Message.messageNumToMessageAlpha(Message, Message.reformerPaquet(paquets_codé))
        return Message.tableauToMessage(paquets_codé_alpha)
    
    def setSignature(self,a,n):
        max = self.matrice_A[0][0]
        #on cherche α = max(A)
        for i in range(len(self.matrice_A)):
            for j in range(len(self.matrice_A)):
                if(self.matrice_A[i][j]>max):
                    max = self.matrice_A[i][j]
                    
        z = (max**(self.b))%self.n
        self.sign = (z**a) % n

    
    def chiffrageMatriceCodage(self,a,n):
        aprime = []
        ligne = []
        # max = A[0][0]
        nbligne = len(self.matrice_A)
        
        #on cherche α = max(A)
        # for i in range(nbligne):
        #     for j in range(nbligne):
        #         if(A[i][j]>max):
        #             max = A[i][j]
                    
        #on calcul A' pour chaque 'case' de la matrice
        for i in range(nbligne):
            for j in range(nbligne):
                ligne.append((self.matrice_A[i][j]**a)%n)
            aprime.append(ligne)
            ligne = []
        return aprime
        
    

        
    
        

    