public class Implication extends OperandeBinaire {

	public Implication() {
		super(" => ");
	}
	
	@Override
	public boolean isSatisfiable() {
		boolean a = this.operandeGauche.isSatisfiable();
		boolean b = this.operandeDroite.isSatisfiable();
		return !a || b;
	}
	
}
