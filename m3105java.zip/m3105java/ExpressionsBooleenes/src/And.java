
public class And extends OperandeBinaire {

	public And() {
		super(".");
	}

	@Override
	public boolean isSatisfiable() {
		return this.operandeGauche.isSatisfiable() && this.operandeDroite.isSatisfiable();
	}
	
}
