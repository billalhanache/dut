
public class Inibition extends OperandeBinaire {

	public Inibition() {
		super("\\");
	}
	
	@Override
	public boolean isSatisfiable() {
		boolean a = this.operandeGauche.isSatisfiable();
		boolean b = this.operandeDroite.isSatisfiable();
		return a && !b;
	}
}
