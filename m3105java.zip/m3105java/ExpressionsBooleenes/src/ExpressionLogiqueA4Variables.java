public class ExpressionLogiqueA4Variables {
	private TableDesSymboles symboles;
	
	public Satisfiable constructionEpressionLogiqueA4Variables() {
		this.symboles = new TableDesSymboles();
		VariableBooleenne a = new VariableBooleenne("a", "Assez d'argent");
		this.symboles.addVariable(a);
		VariableBooleenne b = new VariableBooleenne("b", "Devoirs fini");
		this.symboles.addVariable(b);
		VariableBooleenne c = new VariableBooleenne("c", "Transports en grève");
		this.symboles.addVariable(c);
		VariableBooleenne d = new VariableBooleenne("d", "Automobile familiale disponible");
		this.symboles.addVariable(d);	
		
		OperandeBinaire conjonctionGauche = new And();
		conjonctionGauche.setOperandeGauche(a);
		conjonctionGauche.setOperandeDroite(b);
		
		OperandeBinaire conjonctionDroite= new And();
		
		OperandeUnaire nonC = new Non();
		nonC.setOperande(c);
		conjonctionDroite.setOperandeGauche(nonC);
		conjonctionDroite.setOperandeDroite(d);
		
		OperandeBinaire sortir = new And();
		sortir.setOperandeGauche(conjonctionGauche);
		sortir.setOperandeDroite(conjonctionDroite);
		return sortir;
	}
}