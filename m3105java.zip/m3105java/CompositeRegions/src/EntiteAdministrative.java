import java.text.NumberFormat;

public abstract class EntiteAdministrative {
	protected String libelle;
	
	public EntiteAdministrative(String libelle) {
		this.libelle = libelle;
	}
	
	public abstract int getNbHabitants();
	
	public abstract int getSuperficie();
	
	public String toStringSuperficie() {
		return " pour une superficie de " + NumberFormat.getIntegerInstance().format(this.getNbHabitants()) + " km²";
	}
	
	public String toStringNbHabitants() {
		return " " + NumberFormat.getIntegerInstance().format(this.getNbHabitants()) + " habitants";
	}
	
	public abstract String toString(String nbEspaces);
}
