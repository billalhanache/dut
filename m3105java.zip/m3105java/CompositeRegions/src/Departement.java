
public class Departement extends EntiteAdministrative {
	private int code;
	private int nbHabitants;
	private int superficie;
	
	public Departement(String libelle, int code, int nbHabitants, int superficie) {
		super(libelle);
		this.code = code;
		this.nbHabitants = nbHabitants;
		this.superficie = superficie;
	}
	
	public int getNbHabitants() {
		return this.nbHabitants;
	}
	
	public int getSuperficie() {
		return this.superficie;
	}
	
	@Override
	public String toString(String nbEspaces) {
		return nbEspaces + this.libelle + " ("+this.code+") " + this.toStringNbHabitants() + this.toStringSuperficie();
	}
	
	
	public void changerDeRegion(Region regionFrom , Region regionTo) throws RuntimeException {
		if(regionFrom == null || regionTo == null) throw new RuntimeException("Null");
		regionFrom.remove(this);
		regionTo.add(this);
	}
}
