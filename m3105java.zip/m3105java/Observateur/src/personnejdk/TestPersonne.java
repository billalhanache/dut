package personnejdk;

import static org.junit.Assert.*;

import java.util.Observable;
import java.util.Observer;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestPersonne {
	private Personne personne;
	private ObserverPersonne observer;
	
	public static class ObserverPersonne implements Observer {
		private boolean updated;
		
		public ObserverPersonne() {
			this.updated = false;
		}
	
		public boolean isUpdated() {
			return this.updated;
		}

		@Override
		public void update(Observable s, Object obj) {
			this.updated = true;
		}
	}

	@Before
	public void setUp() throws Exception {
		this.personne = new Personne("Chaudon", "Guillaume");
		this.observer = new ObserverPersonne();
		this.personne.addObserver(this.observer);
	}

	@After
	public void tearDown() throws Exception {
		this.personne = null;
		this.observer = null;
	}

	@Test
	public void testUpdate() {
		this.personne.setNom("Climent");
		assertTrue(this.observer.isUpdated());
	}
	
}
