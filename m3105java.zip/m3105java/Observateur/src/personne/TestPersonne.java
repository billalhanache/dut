package personne;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestPersonne {
	private Personne personne;
	private ObserverPersonne observer;
	
	public static class ObserverPersonne implements Observer {
		private boolean updated;
		
		public ObserverPersonne() {
			this.updated = false;
		}
		
		@Override
		public void update(Subject s) {
			this.updated = true;
		}	
		
		public boolean isUpdated() {
			return this.updated;
		}
	}

	@Before
	public void setUp() throws Exception {
		this.personne = new Personne("Chaudon", "Guillaume");
		this.observer = new ObserverPersonne();
		this.personne.attach(this.observer);
	}

	@After
	public void tearDown() throws Exception {
		this.personne = null;
		this.observer = null;
	}

	@Test
	public void testUpdate() {
		this.personne.setNom("Climent");
		assertTrue(this.observer.isUpdated());
	}
	
}
