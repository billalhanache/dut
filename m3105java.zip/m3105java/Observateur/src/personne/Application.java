package personne;

public class Application {

	public static void main(String[] args) {
		Personne[] listePersonnes = { new Personne("Sedes", "Florence"),
									  new Personne("Viallet", "Fabienne"),
									  new Personne("Julien", "Christine"),
									  new Personne("Percebois", "Christian"),
									  new Personne("Leblanc", "Herve")};
		
		Observer etatCivilToulouse = new ObserverEtatCivil();
		Observer hauteGaronnePTT = new ObserverPTT();
		
		for (Personne p : listePersonnes) {
			p.attach(etatCivilToulouse);
			p.attach(hauteGaronnePTT);
		}
			
		listePersonnes[3].ajoutPrenom("Augustin");
		listePersonnes[4].ajoutPrenom("Just");
		listePersonnes[4].setNom("Lerouge");
	}

}
