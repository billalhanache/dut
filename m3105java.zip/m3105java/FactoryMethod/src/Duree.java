public interface Duree extends Comparable<Duree> {

	public int getHeures();

	public int getMinutes();

	public int getSecondes();

	public void ajouterUneSeconde();
	
	public void ajouterUneMinute();
	
	public void ajouterUneHeure();

}