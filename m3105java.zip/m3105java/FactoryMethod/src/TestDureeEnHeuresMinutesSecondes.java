import org.junit.Before;


public class TestDureeEnHeuresMinutesSecondes extends TestDuree {
	@Before
	public void setUp() {
		this.factory = new FabriqueADureeEnHeuresMinutesSecondes();
	}
}
