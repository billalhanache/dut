
public interface FabriqueADuree {
	public Duree create(int heures, int minutes, int secondes);
}
