import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Test;

public abstract class TestDuree {
	protected FabriqueADuree factory;

	@After
	public void tearDown() {
		this.factory = null;
	}
	
	@Test
	public void testGetters() {
		Duree d = this.factory.create(1, 2, 3);
		assertEquals(1,d.getHeures());
		assertEquals(2,d.getMinutes());
		assertEquals(3,d.getSecondes());
	}

	@Test (expected=IllegalArgumentException.class)
	public void testHeuresNegative() {
		this.factory.create(-1, 2, 3);
	}

	@Test (expected=IllegalArgumentException.class)
	public void testMinutesNegative() {
		this.factory.create(1, -2, 3);
	}

	@Test (expected=IllegalArgumentException.class)
	public void testMinutesSuperieur59() {
		this.factory.create(1, 60, 3);
	}

	@Test (expected=IllegalArgumentException.class)
	public void testSecondesNegative() {
		this.factory.create(1, 2, -3);
	}

	@Test (expected=IllegalArgumentException.class)
	public void testSecondesSuperieur59() {
		this.factory.create(1, 2, 60);
	}

	@Test
	public void testEqualsValeursEgales() {
		assertEquals(this.factory.create(1,2,3),this.factory.create(1,2,3));
	}

	@Test
	public void testEqualsValeursNonEgales() {
		assertNotEquals(this.factory.create(1,2,3),this.factory.create(2,2,3));
		assertNotEquals(this.factory.create(1,2,3),this.factory.create(1,1,3));
		assertNotEquals(this.factory.create(1,2,3),this.factory.create(1,2,2));
	}

	@Test
	public void testAjouterUneSeconde() {
		Duree d123 = this.factory.create(1,2,3);
		d123.ajouterUneSeconde();
		assertEquals(this.factory.create(1,2,4),d123);

		Duree d1259 = this.factory.create(1,2,59);
		d1259.ajouterUneSeconde();
		assertEquals(this.factory.create(1,3,0),d1259);

		Duree d5959 = this.factory.create(1,59,59);
		d5959.ajouterUneSeconde();
		assertEquals(this.factory.create(2,0,0),d5959);
	}
	
	@Test
	public void testAjouterUneMinute() {
		Duree d123 = this.factory.create(1, 2, 3);
		d123.ajouterUneMinute();
		assertEquals(this.factory.create(1, 3, 3), d123);
		
		Duree d1593 = this.factory.create(1, 59, 3);
		d1593.ajouterUneMinute();
		assertEquals(this.factory.create(2, 0, 3), d1593);
	}
	
	@Test
	public void testAjouterUneHeure() {
		Duree d123 = this.factory.create(1, 2, 3);
		d123.ajouterUneHeure();
		assertEquals(this.factory.create(2, 2, 3), d123);
	}
	
	@Test
	public void testCompareTo() {
		assertTrue(this.factory.create(1,2,4).compareTo(this.factory.create(1,0,0)) > 0);
		assertEquals(0,this.factory.create(1,2,4).compareTo(this.factory.create(1,2,4)));
		assertTrue(this.factory.create(1,0,0).compareTo(this.factory.create(1,2,4)) < 0);
	}

	@Test 
	public void testToString() {
		assertEquals("1:2:3", this.factory.create(1,2,3).toString());
	}
}
