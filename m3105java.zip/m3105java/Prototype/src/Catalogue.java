import java.util.List;

public class Catalogue {
	private Immeuble immeuble;
	private Arbre arbre;
	private Banc banc;
	private Toboggan toboggan;
	private Balancoire balancoire;
	private Tourniquet tourniquet;
	private Cite cite;
	
	private static Catalogue instance;

	private Catalogue() {
		this.immeuble = new Immeuble(0D, 0D, "Blanc", 4, 3);
		this.arbre = new Arbre(0D, 0D, 8, "Brun", "Vert");
		this.balancoire = new Balancoire(0D, 0D, "Vert", 3, 2);
		this.banc = new Banc(0D, 0D, "Brun", 1, 2);
		this.toboggan = new Toboggan(0D, 0D, "Jaune", 2, 4);
		this.tourniquet = new Tourniquet(0D, 0D, "Rouge", 1, 3);
		this.cite = new Cite("Caraman");
		
		this.initializeCite();
	}
	
	public static synchronized Catalogue getInstance() {
		if(instance == null)
			instance = new Catalogue();
		return instance;
	}

	private void initializeCite() {
		List<ObjetGraphique> data = cite.getData();
		data.add(immeuble.clone());
		data.add(immeuble.clone());
		data.add(banc.clone());
		data.add(banc.clone());
		data.add(banc.clone());
		data.add(balancoire.clone());
		data.add(toboggan.clone());
		data.add(arbre.clone());
		data.add(arbre.clone());
		cite.setData(data);
	}
	
	public Cite getCite() {
		return cite.clone();
	}

	public Immeuble getImmeuble() {
		return immeuble.clone();
	}

	public Arbre getArbre() {
		return arbre.clone();
	}

	public Banc getBanc() {
		return banc.clone();
	}

	public Toboggan getToboggan() {
		return toboggan.clone();
	}

	public Balancoire getBalancoire() {
		return balancoire.clone();
	}

	public Tourniquet getTourniquet() {
		return tourniquet.clone();
	}

}
