import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ImmeubleTest {
	
	private Immeuble im1, im2;

	@Before
	public void setUp() throws Exception {
		this.im1 = new Immeuble(0d, 0d, "rouge", 8, 3);
		this.im2 = im1.clone();
	}

	@After
	public void tearDown() throws Exception {
		im1 = null;
		im2 = null;
	}

	@Test
	public void testNotSame() {
		assertNotSame(im1, im2);
	}

	@Test
	public void testEquals() {
		assertEquals(im1, im2);
	}
}
