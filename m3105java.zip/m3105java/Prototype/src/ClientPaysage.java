
public class ClientPaysage {

	public static void main(String[] args) {
		Catalogue catalogue = Catalogue.getInstance();
		Cite uneCite = catalogue.getCite();
		Immeuble test = (Immeuble) uneCite.getData().get(0);
		test.setCouleur("Rouge");
		test.translater(3.3, 4.4);
		System.out.println(uneCite);
		Cite uneAutreCite = catalogue.getCite();
		System.out.println(uneAutreCite);
	}

}
