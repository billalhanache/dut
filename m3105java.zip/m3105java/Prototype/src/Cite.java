import java.util.LinkedList;
import java.util.List;

public class Cite implements Cloneable{
	
	private List<ObjetGraphique> objets;
	private String nom;
	
	public Cite(String nom) {
		this.objets = new LinkedList<>();
		this.nom = nom;
	}
	
	public List<ObjetGraphique> getData(){
		return this.objets;
	}
	
	public void setData(List<ObjetGraphique> objets) {
		this.objets = objets;
	}

	public String getNom() {
		return this.nom;
	}
	
	public Cite clone() {
		Cite clone = null;
		try {
			clone = (Cite) super.clone();
			clone.nom = this.nom;
			List<ObjetGraphique> objetsClone = new LinkedList<>();
			for(ObjetGraphique obj : this.objets) {
				objetsClone.add(obj.clone());
			}
			clone.objets = objetsClone;
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		return clone;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cite other = (Cite) obj;
		if (nom == null) {
			if (other.nom != null)
				return false;
		} else if (!nom.equals(other.nom))
			return false;
		if (objets == null) {
			if (other.objets != null)
				return false;
		} else if (!objets.equals(other.objets))
			return false;
		return true;
	}
}
