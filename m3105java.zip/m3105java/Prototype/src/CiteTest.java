import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CiteTest {

	private Cite cite1, cite2;
	private Catalogue cat;
	
	@Before
	public void setUp() throws Exception {
		cat = Catalogue.getInstance();
		cite1 = cat.getCite();
		cite2 = cat.getCite();
	}

	@After
	public void tearDown() throws Exception {
		cite1 = null;
		cite2 = null;
	}

	@Test
	public void testNotSame() {
		assertNotSame(cite1, cite2);
		for(int i = 0; i < cite1.getData().size(); i++) {
			assertNotSame(cite1.getData().get(i), cite2.getData().get(i));
		}
	}
	
	@Test
	public void testEquals() {
		assertEquals(cite1, cite2);
		for(int i = 0; i < cite1.getData().size(); i++) {
			assertEquals(cite1.getData().get(i), cite2.getData().get(i));
		}
	}
}
