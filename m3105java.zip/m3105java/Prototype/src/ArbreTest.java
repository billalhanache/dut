import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ArbreTest {
	
	private Arbre ab1, ab2;

	@Before
	public void setUp() throws Exception {
		this.ab1 = new Arbre(0d, 0d, 6, "marron", "vert");
		this.ab2 = ab1.clone();
	}

	@After
	public void tearDown() throws Exception {
		this.ab1 = null;
		this.ab2 = null;
	}

	@Test
	public void testNotSame() {
		assertNotSame(ab1, ab2);
	}
	
	@Test
	public void testEquals() {
		assertEquals(ab1, ab2);
	}

}
