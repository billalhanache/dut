public class ExpressionsDeLorraine extends Expressions {

	public ExpressionsDeLorraine(Expressions suivant) {
		super("Expressions de Lorraine...", suivant);
		
		this.expressions.add(new Entry("Oh l'autre !",  "Tu rigoles !"));
		this.expressions.add(new Entry("Tu viens avec ?", "Viens-tu avec nous ?"));
		this.expressions.add(new Entry("Brimbelle", "Myrtille"));
		this.expressions.add(new Entry("Oh l'autre !",  "Tu rigoles !"));
		this.expressions.add(new Entry("Beuille", "un bleu"));
		this.expressions.add(new Entry("Faire bleu", "secher les cours"));
		this.expressions.add(new Entry("Ca caille", "Il fait froid"));
		this.expressions.add(new Entry("Chlass","Couteau"));
		this.expressions.add(new Entry("Clanche", "La poignee de porte"));
		this.expressions.add(new Entry("Ca gehtas ?", "Ca va bien ?"));
		this.expressions.add(new Entry("Entre midi", "Entre midi et 14h"));
		this.expressions.add(new Entry("Flot", "noeud"));
		this.expressions.add(new Entry("Nareux", "Personne qui n'aime pas boire apres quelqu'un dans la meme bouteille"));
		this.expressions.add(new Entry("Schnek", "Pain aux raisins"));
		this.expressions.add(new Entry("Schlapp", "Savate"));
		this.expressions.add(new Entry("Schlouc", "Une gorgee"));	
	}
	
	public ExpressionsDeLorraine() {
		this(null);
	}

}
