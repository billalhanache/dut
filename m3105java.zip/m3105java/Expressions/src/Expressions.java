import java.util.LinkedList;
import java.util.List;

public abstract class Expressions {
	private String nom;
	protected List<Entry> expressions;
	private Expressions suivant;
	
	public Expressions(String nom, Expressions suivant) {
		this.nom = nom;
		this.expressions = new LinkedList<Entry>();
		this.suivant = suivant;
	}
	
	public void rechercherExpressions(String lettres) {
		System.out.println(this.nom);
		for (Entry e : this.expressions) {
			String name = e.getName().toLowerCase();
			if (name.contains(lettres)) {
				System.out.println(e.getName() + " : " + e.getDefinition());
			}				
		}
		
		if(this.suivant != null) {
			this.suivant.rechercherExpressions(lettres);
		}
	}
}
