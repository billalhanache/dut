public class ExpressionsToulousaines extends Expressions {

	public ExpressionsToulousaines(Expressions suivant) {
		super("Expressions Toulousaines...", suivant);
		
		this.expressions.add(new Entry("Aimable", "gentil, agreable. Elle est aimable, la maitresse ?"));
		this.expressions.add(new Entry("Bader", "rester bouche bee devant. Ta soeur, elle arrete pas de le bader."));
		this.expressions.add(new Entry("Banane", "mauvaise note. C'est la premiere fois de l'annee que je prends pas une banane."));
		this.expressions.add(new Entry("Cagade",  "chiure, echec. ca a ete une cagade totale. De l'occitan cagada, chiee."));
		this.expressions.add(new Entry("Cagnasse", "grosse chaleur, canicule, celle qui coute des litres de sueur a chaque mouvement."));
		this.expressions.add(new Entry("Caguer", "Tu vas pas nous en caguer une pendule ! Il nous fait caguer, l'autre ! De l'occitan cagar, chier."));
		this.expressions.add(new Entry("Diner", "repas de midi, dejeuner. Venez vers midi pour diner ! De l'occitan dinnar."));
		this.expressions.add(new Entry("Empapaouter", "arnaquer, rouler. Je te l'ai empapaoute vite fait ! De l'occitan empapautar."));
		this.expressions.add(new Entry("Franchimand", "francais du nord (de la Loire). Le probleme avec les franchimands, c'est qu'ils se croient plus intelligents que toi."));
		this.expressions.add(new Entry("Garnir", "remplir un formulaire. Vous me garnissez encore cette feuille, et ce sera bon."));
		this.expressions.add(new Entry("Patac", "Il s'est pris un patac qui l'a ensuque*, et il s'est esplaterne."));
		this.expressions.add(new Entry("Que", "car, parce que. Couvre-toi que tu vas avoir froid. De l'occitan que, car."));
		this.expressions.add(new Entry("Pigne", "fruit de conifere. Prends des pignes pour lancer le feu."));
		this.expressions.add(new Entry("Rien que", "Il est venu rien que lui. Rien que ? Oui, rien que lui !"));
		this.expressions.add(new Entry("Tavanard", "objet qui boudonne fort en allant vite. La moto, elle m'a depasse comme un tavanard."));
	}
	
	public ExpressionsToulousaines() {
		this(null);
	}
}
