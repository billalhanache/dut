
public class Client {
	public static void main(String[] args) {
		VehiculeFactory f = new VehiculeFactory();
		
		Voiture v = (Voiture) f.getVehicule(VehiculeFactory.VEHICULE_VOITURE);
		
		System.out.println(v.describe());
		
		Moto m = (Moto) f.getVehicule(VehiculeFactory.VEHICULE_MOTO);
		
		System.out.println(m.describe());
		
	}
}
