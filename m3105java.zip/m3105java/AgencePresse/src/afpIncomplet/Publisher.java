package afpIncomplet;

import java.util.LinkedHashSet;
import java.util.Set;

public class Publisher {
	
	private Set<Subscriber> observers;
	
	public Publisher(){
		this.observers = new LinkedHashSet<Subscriber>();
	}
	
	public void attach(Subscriber obs){
		this.observers.add(obs);
	}
	
	public void detach(Subscriber obs){
		this.observers.remove(obs);
	}
	
	public void notifyObservers(){
		for(Subscriber sub : this.observers) {
			sub.update(this);
		}
	}
}
