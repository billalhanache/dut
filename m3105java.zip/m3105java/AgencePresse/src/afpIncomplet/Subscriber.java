package afpIncomplet;

public interface Subscriber {
	public void update(Publisher s);

}
