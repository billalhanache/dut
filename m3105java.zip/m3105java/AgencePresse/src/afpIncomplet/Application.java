package afpIncomplet;

public class Application {

	public static void main(String[] args) {
		AgencePresse afp = new AgencePresse();
		Subscriber email = new EmailSubscriber("nom_prenom@gmail.com");
		Subscriber tel = new SMSSubscriber("+33 06 xx xx xx xx");
		afp.attach(tel);
		afp.attach(email);
		
		for (int i = 1; i <= 101; i++)
			afp.addNews("Message important num " + i);
	}

}
