package afpIncomplet;

public class NewsImage {
	private String content;
	private String imageLocation;
	
	public NewsImage(String content, String imageLocation) {
		this.content = content;
		this.imageLocation = imageLocation;
	}

	public String getContent() {
		return content;
	}

	public String getImageLocation() {
		return imageLocation;
	}
	
	@Override
	public String toString() {
		return this.content + " [" + this.imageLocation + "]";
	}
}
