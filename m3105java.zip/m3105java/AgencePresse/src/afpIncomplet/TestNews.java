package afpIncomplet;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestNews {
	private AgencePresse afp;
	private AgencePresseWithImage lemonde;
	private EmailSubscriber email;
	private SMSSubscriber tel;
	private MMSSubscriber mms;
	private String newsTest;
	private NewsImage newsImage;
	
	@Before
	public void setUp() throws Exception {
		this.afp = new AgencePresse();
		this.lemonde = new AgencePresseWithImage();
		this.email = new EmailSubscriber("nom_prenom@gmail.com");
		this.tel = new SMSSubscriber("+33 06 xx xx xx xx");
		this.mms = new MMSSubscriber("+33 06 xx xx xx xx");
		this.afp.attach(this.email);
		this.afp.attach(this.tel);
		this.lemonde.attach(this.mms);
		this.newsTest = "Test de news";
		this.newsImage = new NewsImage(this.newsTest, "http://localhost/image.png");
	}

	@After
	public void tearDown() throws Exception {
		this.afp = null;
		this.lemonde = null;
		this.email = null;
		this.tel = null;
		this.mms = null;
		this.newsTest = null;
		this.newsImage = null;
	}

	@Test
	public void testNewsEmail() {
		this.afp.addNews(newsTest);
		assertEquals(this.email.getDernierMessage(), this.newsTest);
	}
	
	@Test
	public void testNewsSMS() {
		this.afp.addNews(newsTest);
		assertEquals(this.tel.getDernierMessage(), this.newsTest);
	}
	
	@Test
	public void testNewsMMS() {
		this.lemonde.addNews(newsImage.getContent(), newsImage.getImageLocation());
		assertEquals(this.mms.getDernierMessage(), this.newsImage.toString());
	}
}
