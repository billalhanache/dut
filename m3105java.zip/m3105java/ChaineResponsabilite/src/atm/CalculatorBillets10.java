package atm;

import java.util.List;

public class CalculatorBillets10 extends CalculatorBillets {
	
	public CalculatorBillets10(CalculatorBillets suivant) {
		super(suivant);
	}
	
	public void donnerBillets(Montant montant, List<Couple> proposition, EtatDistributeur etat) {
		if (montant.getMontant() > 0) {
			int nBillets10 = Math.min(montant.getMontant()/10, etat.getNb10Disponible());
			montant.setMontant(montant.getMontant() - nBillets10 * 10);
			etat.setNb10Disponible(etat.getNb10Disponible() - nBillets10);
			proposition.add(new Couple(10,nBillets10));
		}
		
		super.donnerBillets(montant, proposition, etat);
	}
}
