package atm;

import java.util.LinkedList;
import java.util.List;

public class Distributeur {

	private EtatDistributeur etat;

	public Distributeur(int nb50, int nb20, int nb10) {
		this(nb50, nb20, nb10, 0);
	}

	public Distributeur(int nb50, int nb20, int nb10, int nb5) {
		this.etat = new EtatDistributeur();

		recharger(nb50, nb20, nb10, nb5);
	}

	public void recharger(int nb50, int nb20, int nb10) {
		this.etat.setNb50Disponible(nb50);
		this.etat.setNb20Disponible(nb20);
		this.etat.setNb10Disponible(nb10);
		this.etat.setNb5Disponible(0);
	}

	public void recharger(int nb50, int nb20, int nb10, int nb5) {
		this.etat.setNb50Disponible(nb50);
		this.etat.setNb20Disponible(nb20);
		this.etat.setNb10Disponible(nb10);
		this.etat.setNb5Disponible(nb5);
	}

	public List<Couple> donnerBillets(int montant) {
		Montant m = new Montant(montant);
		List<Couple> proposition = new LinkedList<Couple>();

		CalculatorBillets c = new CalculatorBillets50(new CalculatorBillets20(new CalculatorBillets10(null)));
		c.donnerBillets(m, proposition, this.etat);

		return proposition;
	}

	public List<Couple> donnerBilletsPetitesCoupures(int montant) {
		Montant m = new Montant(montant);
		List<Couple> proposition = new LinkedList<Couple>();
		CalculatorBillets c = new CalculatorBillets5(
				new CalculatorBillets50(new CalculatorBillets20(new CalculatorBillets10(null))));
		c.donnerBillets(m, proposition, this.etat);

		return proposition;
	}

	public List<Couple> donnerBilletsGrossesCoupures(int montant) {
		Montant m = new Montant(montant);
		List<Couple> proposition = new LinkedList<Couple>();
		CalculatorBillets c = new CalculatorBilletsGC50(
				new CalculatorBilletsGC20(new CalculatorBilletsGC10(new CalculatorBilletsGC5(null))));
		
		c.donnerBillets(m, proposition, this.etat);
		return proposition;
	}

	public String toStringProposition(List<Couple> proposition, int montant) {
		StringBuffer res = new StringBuffer();
		res.append("Montant a debiter : " + montant + "€ \n");
		for (Couple c : proposition) {
			res.append(c.toString() + '\n');
		}
		res.append("Montant restant du : " + this.montantRestantDu(proposition, montant));
		return res.toString();
	}

	public int montantRestantDu(List<Couple> proposition, int montant) {
		int montantRestantDu = montant;
		for (Couple c : proposition) {
			montantRestantDu -= c.getValeurBillet() * c.getNombreBilletsDelivres();
		}
		return montantRestantDu;
	}
}
