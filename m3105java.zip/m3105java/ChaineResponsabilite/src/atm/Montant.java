package atm;

public class Montant {
	private int montant;
	
	public Montant(int montant) {
		this.montant = montant;
	}

	public int getMontant() {
		return montant;
	}

	public void setMontant(int montant) {
		this.montant = montant;
	}
}
