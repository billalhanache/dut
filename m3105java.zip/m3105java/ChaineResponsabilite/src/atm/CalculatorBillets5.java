package atm;

import java.util.List;

public class CalculatorBillets5 extends CalculatorBillets {

	public CalculatorBillets5(CalculatorBillets suivant) {
		super(suivant);
	}
	
	public void donnerBillets(Montant montant, List<Couple> proposition, EtatDistributeur etat) {
		if(montant.getMontant() <= 100 && montant.getMontant() > 20) {
			int nBillets = Math.min(etat.getNb5Disponible(), 2);
			montant.setMontant(montant.getMontant() - nBillets * 5);
			etat.setNb5Disponible(etat.getNb5Disponible() - nBillets);
			
			if(nBillets > 0) {
				proposition.add(new Couple(5, nBillets));
			}
		}
		
		super.donnerBillets(montant, proposition, etat);
	}
}
