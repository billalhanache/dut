package atm;

import java.util.List;

public class CalculatorBilletsGC50 extends CalculatorBillets {

	public CalculatorBilletsGC50(CalculatorBillets suivant) {
		super(suivant);
	}	

	public void donnerBillets(Montant montant, List<Couple> proposition, EtatDistributeur etat) {
		int nBillets = Math.min(montant.getMontant() / 50, etat.getNb50Disponible());
		montant.setMontant(montant.getMontant() - nBillets * 50);
		etat.setNb50Disponible(etat.getNb50Disponible() - nBillets);

		if(nBillets > 0) {
			proposition.add(new Couple(50, nBillets));
		}

		super.donnerBillets(montant, proposition, etat);
	}

}
