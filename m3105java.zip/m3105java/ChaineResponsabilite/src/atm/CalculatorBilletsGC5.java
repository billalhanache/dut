package atm;

import java.util.List;

public class CalculatorBilletsGC5 extends CalculatorBillets {

	public CalculatorBilletsGC5(CalculatorBillets suivant) {
		super(suivant);
	}	

	public void donnerBillets(Montant montant, List<Couple> proposition, EtatDistributeur etat) {
		int nBillets = Math.min(montant.getMontant() / 5, etat.getNb5Disponible());
		montant.setMontant(montant.getMontant() - nBillets * 5);
		etat.setNb5Disponible(etat.getNb5Disponible() - nBillets);

		if(nBillets > 0) {
			proposition.add(new Couple(5, nBillets));
		}

		super.donnerBillets(montant, proposition, etat);
	}

}
