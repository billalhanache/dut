import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import atm.Couple;
import atm.Distributeur;

public class TestDistributeur {
	private Distributeur d;
	private List<Couple> proposition;

	@Before
	public void setUp() throws Exception {
		this.d = new Distributeur(10, 10, 10, 10);
	}

	@After
	public void tearDown() throws Exception {
		this.d = null;
	}

	@Test
	public void test10() {
		this.proposition = this.d.donnerBillets(10);

		assertEquals(0, d.montantRestantDu(this.proposition, 10));
		assertEquals(1, this.proposition.get(0).getNombreBilletsDelivres());
		assertEquals(10, this.proposition.get(0).getValeurBillet());
	}

	@Test
	public void test10Petites() {
		this.proposition = this.d.donnerBilletsPetitesCoupures(10);

		assertEquals(0, d.montantRestantDu(this.proposition, 10));
		assertEquals(1, this.proposition.get(0).getNombreBilletsDelivres());
		assertEquals(10, this.proposition.get(0).getValeurBillet());
	}

	@Test
	public void test20() {
		this.proposition = d.donnerBillets(20);

		assertEquals(0, d.montantRestantDu(this.proposition, 20));
		assertEquals(2, this.proposition.get(0).getNombreBilletsDelivres());
		assertEquals(10, this.proposition.get(0).getValeurBillet());
	}
	
	@Test
	public void test20Petites() {
		this.proposition = d.donnerBilletsPetitesCoupures(20);

		assertEquals(0, d.montantRestantDu(this.proposition, 20));
		assertEquals(2, this.proposition.get(0).getNombreBilletsDelivres());
		assertEquals(10, this.proposition.get(0).getValeurBillet());
	}

	@Test
	public void test30() {
		this.proposition = d.donnerBillets(30);

		assertEquals(0, d.montantRestantDu(this.proposition, 30));
		assertEquals(1, this.proposition.get(0).getNombreBilletsDelivres());
		assertEquals(20, this.proposition.get(0).getValeurBillet());
		assertEquals(1, this.proposition.get(1).getNombreBilletsDelivres());
		assertEquals(10, this.proposition.get(1).getValeurBillet());
	}
	
	@Test
	public void test30Petites() {
		this.proposition = d.donnerBilletsPetitesCoupures(30);

		assertEquals(0, d.montantRestantDu(this.proposition, 30));
		assertEquals(2, this.proposition.get(0).getNombreBilletsDelivres());
		assertEquals(5, this.proposition.get(0).getValeurBillet());
		assertEquals(2, this.proposition.get(1).getNombreBilletsDelivres());
		assertEquals(10, this.proposition.get(1).getValeurBillet());
	}

	@Test
	public void test40() {
		this.proposition = d.donnerBillets(40);

		assertEquals(0, d.montantRestantDu(this.proposition, 40));
		assertEquals(1, this.proposition.get(0).getNombreBilletsDelivres());
		assertEquals(20, this.proposition.get(0).getValeurBillet());
		assertEquals(2, this.proposition.get(1).getNombreBilletsDelivres());
		assertEquals(10, this.proposition.get(1).getValeurBillet());
	}
	
	@Test
	public void test40Petites() {
		this.proposition = d.donnerBilletsPetitesCoupures(40);

		assertEquals(0, d.montantRestantDu(this.proposition, 40));
		assertEquals(2, this.proposition.get(0).getNombreBilletsDelivres());
		assertEquals(5, this.proposition.get(0).getValeurBillet());
		assertEquals(1, this.proposition.get(1).getNombreBilletsDelivres());
		assertEquals(20, this.proposition.get(1).getValeurBillet());
		assertEquals(1, this.proposition.get(2).getNombreBilletsDelivres());
		assertEquals(10, this.proposition.get(2).getValeurBillet());
	}

	@Test
	public void test50() {
		this.proposition = d.donnerBillets(50);

		assertEquals(0, d.montantRestantDu(this.proposition, 50));
		assertEquals(2, this.proposition.get(0).getNombreBilletsDelivres());
		assertEquals(20, this.proposition.get(0).getValeurBillet());
		assertEquals(1, this.proposition.get(1).getNombreBilletsDelivres());
		assertEquals(10, this.proposition.get(1).getValeurBillet());
	}
	
	@Test
	public void test50Petites() {
		this.proposition = d.donnerBilletsPetitesCoupures(50);

		assertEquals(0, d.montantRestantDu(this.proposition, 50));
		assertEquals(2, this.proposition.get(0).getNombreBilletsDelivres());
		assertEquals(5, this.proposition.get(0).getValeurBillet());
		assertEquals(1, this.proposition.get(1).getNombreBilletsDelivres());
		assertEquals(20, this.proposition.get(1).getValeurBillet());
		assertEquals(2, this.proposition.get(2).getNombreBilletsDelivres());
		assertEquals(10, this.proposition.get(2).getValeurBillet());
	}

	@Test
	public void test60() {
		this.proposition = d.donnerBillets(60);

		assertEquals(0, d.montantRestantDu(this.proposition, 60));
		assertEquals(2, this.proposition.get(0).getNombreBilletsDelivres());
		assertEquals(20, this.proposition.get(0).getValeurBillet());
		assertEquals(2, this.proposition.get(1).getNombreBilletsDelivres());
		assertEquals(10, this.proposition.get(1).getValeurBillet());
	}
	
	@Test
	public void test60Petites() {
		this.proposition = d.donnerBilletsPetitesCoupures(60);

		assertEquals(0, d.montantRestantDu(this.proposition, 60));
		assertEquals(2, this.proposition.get(0).getNombreBilletsDelivres());
		assertEquals(5, this.proposition.get(0).getValeurBillet());
		assertEquals(2, this.proposition.get(1).getNombreBilletsDelivres());
		assertEquals(20, this.proposition.get(1).getValeurBillet());
		assertEquals(1, this.proposition.get(2).getNombreBilletsDelivres());
		assertEquals(10, this.proposition.get(2).getValeurBillet());
	}

	@Test
	public void test70() {
		this.proposition = d.donnerBillets(70);

		assertEquals(0, d.montantRestantDu(this.proposition, 70));
		assertEquals(3, this.proposition.get(0).getNombreBilletsDelivres());
		assertEquals(20, this.proposition.get(0).getValeurBillet());
		assertEquals(1, this.proposition.get(1).getNombreBilletsDelivres());
		assertEquals(10, this.proposition.get(1).getValeurBillet());
	}

	@Test
	public void test70Petites() {
		this.proposition = d.donnerBilletsPetitesCoupures(70);

		assertEquals(0, d.montantRestantDu(this.proposition, 70));
		assertEquals(2, this.proposition.get(0).getNombreBilletsDelivres());
		assertEquals(5, this.proposition.get(0).getValeurBillet());
		assertEquals(2, this.proposition.get(1).getNombreBilletsDelivres());
		assertEquals(20, this.proposition.get(1).getValeurBillet());
		assertEquals(2, this.proposition.get(2).getNombreBilletsDelivres());
		assertEquals(10, this.proposition.get(2).getValeurBillet());
	}

	@Test
	public void test100() {
		this.proposition = d.donnerBillets(100);

		assertEquals(0, d.montantRestantDu(this.proposition, 100));
		assertEquals(1, this.proposition.get(0).getNombreBilletsDelivres());
		assertEquals(50, this.proposition.get(0).getValeurBillet());
		assertEquals(2, this.proposition.get(1).getNombreBilletsDelivres());
		assertEquals(20, this.proposition.get(1).getValeurBillet());
		assertEquals(1, this.proposition.get(2).getNombreBilletsDelivres());
		assertEquals(10, this.proposition.get(2).getValeurBillet());
	}
	
	@Test
	public void test100Petites() {
		this.proposition = d.donnerBilletsPetitesCoupures(100);

		assertEquals(0, d.montantRestantDu(this.proposition, 100));
		assertEquals(2, this.proposition.get(0).getNombreBilletsDelivres());
		assertEquals(5, this.proposition.get(0).getValeurBillet());
		assertEquals(4, this.proposition.get(1).getNombreBilletsDelivres());
		assertEquals(20, this.proposition.get(1).getValeurBillet());
		assertEquals(1, this.proposition.get(2).getNombreBilletsDelivres());
		assertEquals(10, this.proposition.get(2).getValeurBillet());
	}

	@Test
	public void test110() {
		this.proposition = d.donnerBillets(110);

		assertEquals(0, d.montantRestantDu(this.proposition, 110));
		assertEquals(1, this.proposition.get(0).getNombreBilletsDelivres());
		assertEquals(50, this.proposition.get(0).getValeurBillet());
		assertEquals(2, this.proposition.get(1).getNombreBilletsDelivres());
		assertEquals(20, this.proposition.get(1).getValeurBillet());
		assertEquals(2, this.proposition.get(2).getNombreBilletsDelivres());
		assertEquals(10, this.proposition.get(2).getValeurBillet());
	}

	@Test
	public void test210() {
		this.proposition = d.donnerBillets(210);

		assertEquals(0, d.montantRestantDu(this.proposition, 210));
		assertEquals(2, this.proposition.get(0).getNombreBilletsDelivres());
		assertEquals(50, this.proposition.get(0).getValeurBillet());
		assertEquals(5, this.proposition.get(1).getNombreBilletsDelivres());
		assertEquals(20, this.proposition.get(1).getValeurBillet());
		assertEquals(1, this.proposition.get(2).getNombreBilletsDelivres());
		assertEquals(10, this.proposition.get(2).getValeurBillet());
	}

	@Test
	public void test310() {
		this.proposition = d.donnerBillets(310);

		assertEquals(0, d.montantRestantDu(this.proposition, 310));
		assertEquals(3, this.proposition.get(0).getNombreBilletsDelivres());
		assertEquals(50, this.proposition.get(0).getValeurBillet());
		assertEquals(7, this.proposition.get(1).getNombreBilletsDelivres());
		assertEquals(20, this.proposition.get(1).getValeurBillet());
		assertEquals(2, this.proposition.get(2).getNombreBilletsDelivres());
		assertEquals(10, this.proposition.get(2).getValeurBillet());
	}

	@Test
	public void test3000() {
		this.proposition = d.donnerBillets(3000);

		assertEquals(2200, d.montantRestantDu(this.proposition, 3000));
		assertEquals(10, this.proposition.get(0).getNombreBilletsDelivres());
		assertEquals(50, this.proposition.get(0).getValeurBillet());
		assertEquals(10, this.proposition.get(1).getNombreBilletsDelivres());
		assertEquals(20, this.proposition.get(1).getValeurBillet());
		assertEquals(10, this.proposition.get(2).getNombreBilletsDelivres());
		assertEquals(10, this.proposition.get(2).getValeurBillet());
	}
}
