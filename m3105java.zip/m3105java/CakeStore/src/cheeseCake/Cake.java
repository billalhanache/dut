package cheeseCake;

public interface Cake extends Cloneable {
	public Cake prepareCake();
}
