package cheeseCake;

public class CheeseCake implements Cake {
	private String sugar;
	private String butter;
	private String cheese;
	private String name;

	public void addSugar(String sugar) {
		this.sugar = sugar;
	}

	public void addButter(String butter) {
		this.butter = butter;
	}

	public void addCheese(String cheese) {
		this.cheese = cheese;
	}

	public void setCustomerName(String name) {
		this.name = name;
	}

	public Cake prepareCake() {
		Cake cakeClone = null;
		try {
			cakeClone = (Cake) super.clone();
		} catch(CloneNotSupportedException e) {
			e.printStackTrace();
		}
		return cakeClone;
	}

	@Override
	public String toString() {
		return "Sugar:" + this.sugar + ", Butter:" + this.butter + ", Name:" + this.name + ", Cheese:" + this.cheese;
	}
}
