package start;

public class ExpressionsDeLorraine extends Expressions {

	public ExpressionsDeLorraine() {
		super("Expressions de Lorraine ...");
		this.expressions.add(new Entry("Oh l�autre !",  "Tu rigoles !"));
		this.expressions.add(new Entry("Tu viens avec ?", "Viens-tu avec nous ?"));
		this.expressions.add(new Entry("Brimbelle", "Myrtille"));
		this.expressions.add(new Entry("Oh l�autre !",  "Tu rigoles !"));
		this.expressions.add(new Entry("Beuille", "un bleu"));
		this.expressions.add(new Entry("Faire bleu", "s�cher les cours"));
		this.expressions.add(new Entry("Ca caille", "Il fait froid"));
		this.expressions.add(new Entry("Chlass","Couteau"));
		this.expressions.add(new Entry("Clanche", "La poign�e de porte"));
		this.expressions.add(new Entry("Ca geht�s ?", "Ca va bien ?"));
		this.expressions.add(new Entry("Entre midi", "Entre midi et 14h"));
		this.expressions.add(new Entry("Flot", "noeud"));
		this.expressions.add(new Entry("Nareux", "Personne qui n�aime pas boire apr�s quelqu�un dans la m�me bouteille"));
		this.expressions.add(new Entry("Schnek", "Pain aux raisins"));
		this.expressions.add(new Entry("Schlapp", "Savate"));
		this.expressions.add(new Entry("Schlouc", "Une gorg�e"));	
	}

}
