package chaine;

public abstract class Handler {
	private Handler next;
	
	public void handle() {
		if(next != null) {
			this.next.handle();
		}
	}
	
	public void setNext(Handler next) {
		this.next = next;
	}
}
