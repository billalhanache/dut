package chaine;

public class HandlerA extends Handler {
	public void handle() {
		System.out.println("Handled by A !");
		
		super.handle();
	}
}
