package competences;

public class CompetencesCommune extends Competences {

	public CompetencesCommune() {
		super("Commune");
		this.competences.put("Enseignement","�coles (b�timents)");
		this.competences.put("Culture et vie sociale","�ducation, cr�ation, biblioth�ques, mus�es, archives");
		this.competences.put("Enfance","cr�ches, centres de loisirs");
		this.competences.put("sports et loisirs","�quipements et subventions, tourisme");
		this.competences.put("Action sociale et m�dico-sociale","CCAS : centre communal d�action sociale");
		this.competences.put("Urbanisme","plan local d�urbanisme, sch�ma de coh�rence territoriale, permis de construire, zone d�am�nagement concert�");
		this.competences.put("Am�nagement du territoir","Sch�ma r�gional (avis, approbation)");
		this.competences.put("Environnement","Espaces naturels, collecte et traitement des d�chets, Eau (distribution, assainissement), �nergie (distribution)");
		this.competences.put("Grands �quipements","Ports de plaisance, A�rodromes");
		this.competences.put("D�veloppement �conomique","Aides indirectes");
		this.competences.put("S�curit�","Police municipale, Circulation et stationnement, Pr�vention de la d�linquance");
	}
}
