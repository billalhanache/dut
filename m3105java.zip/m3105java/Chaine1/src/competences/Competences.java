package competences;

import java.util.HashMap;
import java.util.Map;

public abstract class Competences {
	private String name;
	protected Map<String, String> competences;
	private Competences next;
	
	public Competences(String name) {
		this.name = name;
		this.competences = new HashMap<>();
	}
	
	public void setSuivant(Competences next) {
		this.next = next;
	}
	
	public void rechercheCompetences(String competence) {
		System.out.print(this.name + " : ");
		boolean rien = true;
		for (String s:this.competences.values()) {
			String competences = s.toLowerCase();
			if (competences.contains(competence)) {
				System.out.print(s);
				rien = false;
			}				
		}
		
		if (rien)
			System.out.println("-");
		else
			System.out.println();
		
		if(this.next != null) {
			this.next.rechercheCompetences(competence);
		}
	}
	
	public void afficherDomaineCompetences(String domaine) {
		System.out.print(this.name + " : ");
		String competences = this.competences.get(domaine);
		if (competences == null)
			System.out.println("-");
		else
			System.out.println(competences);
		
		if(this.next != null) {
			this.next.afficherDomaineCompetences(domaine);
		}
	}
}
