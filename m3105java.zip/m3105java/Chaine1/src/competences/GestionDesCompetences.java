package competences;

public class GestionDesCompetences {
	
	public void rechercherUneCompetenceDuBasVersLeHaut(String competence) {
		System.out.println("Recherche de la responsabilit� de la comp�tence " + competence);
		CompetencesCommune commune = new CompetencesCommune();
		CompetencesDepartement departement = new CompetencesDepartement();
		CompetencesRegion region = new CompetencesRegion();
		CompetencesEtat etat = new CompetencesEtat();
		
		commune.setSuivant(departement);
		departement.setSuivant(region);
		region.setSuivant(etat);
		
		commune.rechercheCompetences(competence);
	}

	public void rechercherUneCompetenceDuHautVersLeBas(String competence) {
		System.out.println("Recherche de la responsabilit� de la comp�tence " + competence);
		
		CompetencesCommune commune = new CompetencesCommune();
		CompetencesDepartement departement = new CompetencesDepartement();
		CompetencesRegion region = new CompetencesRegion();
		CompetencesEtat etat = new CompetencesEtat();
		
		etat.setSuivant(region);
		region.setSuivant(departement);
		departement.setSuivant(commune);
		
		etat.rechercheCompetences(competence);
	}
	
	public void afficherCompetencesDomaineDuBasVersLeHaut(String domaine) {
		System.out.println("afficher les compétences du domaine " + domaine);
		
		CompetencesCommune commune = new CompetencesCommune();
		CompetencesDepartement departement = new CompetencesDepartement();
		CompetencesRegion region = new CompetencesRegion();
		CompetencesEtat etat = new CompetencesEtat();
		
		commune.setSuivant(departement);
		departement.setSuivant(region);
		region.setSuivant(etat);

		commune.afficherDomaineCompetences(domaine);
	}
	
	public void afficherCompetencesDomaineRegionDepartementCommuneEtat(String domaine) {
		System.out.println("afficher les compétences du domaine " + domaine);
		
		CompetencesCommune commune = new CompetencesCommune();
		CompetencesDepartement departement = new CompetencesDepartement();
		CompetencesRegion region = new CompetencesRegion();
		CompetencesEtat etat = new CompetencesEtat();
		
		region.setSuivant(departement);
		departement.setSuivant(commune);
		commune.setSuivant(etat);
		
		region.afficherDomaineCompetences(domaine);
	}
	
	public static void main(String[] args) {
		GestionDesCompetences france = new GestionDesCompetences();
		
		france.rechercherUneCompetenceDuBasVersLeHaut("police");
		System.out.println();
		france.rechercherUneCompetenceDuBasVersLeHaut("a�rodrome");
		System.out.println();
		france.rechercherUneCompetenceDuBasVersLeHaut("handicap");
		System.out.println();
		france.rechercherUneCompetenceDuHautVersLeBas("port");
		System.out.println();
		france.rechercherUneCompetenceDuHautVersLeBas("universit�");
		System.out.println();
		france.afficherCompetencesDomaineDuBasVersLeHaut("Enseignement");
		System.out.println();
		france.afficherCompetencesDomaineDuBasVersLeHaut("Urbanisme");
		System.out.println();
		france.afficherCompetencesDomaineRegionDepartementCommuneEtat("Environnement");
	}

}
