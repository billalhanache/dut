package competences;

public class CompetencesRegion extends Competences {

	public CompetencesRegion() {
		super("Region");
		this.competences.put("Formation Professionnelle et Apprentissage","D�finition de la politique r�gionale et mise en �uvre");
		this.competences.put("Enseignement","Lyc�es (b�timents, personnels ouvriers, techniciens et de service)");
		this.competences.put("Culture et vie sociale","patrimoine, �ducation, cr�ation, biblioth�ques, mus�es, archives");
		this.competences.put("sports et loisirs","subventions, tourisme");
		this.competences.put("Am�nagement du territoir","Sch�ma r�gional (�laboration), contrat de projet �tat/r�gion");
		this.competences.put("Environnement","Espaces naturels, Parcs R�gionaux, participation au sch�ma d�am�nagement et de gestion des eaux");
		this.competences.put("Grands �quipements","Ports fluviaux, A�rodromes");
		this.competences.put("D�veloppement �conomique","Aides directes et indirectes");
	}
}
