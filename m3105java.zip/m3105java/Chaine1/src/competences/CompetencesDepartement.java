package competences;

public class CompetencesDepartement extends Competences {

	public CompetencesDepartement() {
		super("Departement");
		this.competences.put("Enseignement","Coll�ges (b�timents, personnels ouvriers, techniciens et de service)");
		this.competences.put("Culture et vie sociale","�ducation, cr�ation, biblioth�ques, mus�es, archives");
		this.competences.put("Action sociale et m�dico-sociale","protection maternelle et infantile, aide sociale � l�enfance");
		this.competences.put("Am�nagement du territoir","Sch�ma r�gional (avis, approbation)");
		this.competences.put("Environnement","Espaces naturels, D�chets (plan d�partemental), participation au sch�ma d�am�nagement et de gestion des eaux");
		this.competences.put("Grands �quipements","Ports maritimes, de commerce et de p�che, A�rodromes");
		this.competences.put("D�veloppement �conomique","Aides indirectes");
		this.competences.put("S�curit�","Circulation, Pr�vention de la d�linquance, Incendie et secours");
	}
}
