
public class CompetencesRegion extends Competences {

	public CompetencesRegion(Competences suivant) {
		super("Region", suivant);
		
		this.competences.put("Formation Professionnelle et Apprentissage","Definition de la politique regionale et mise en euvre");
		this.competences.put("Enseignement","Lycees (betiments, personnels ouvriers, techniciens et de service)");
		this.competences.put("Culture et vie sociale","patrimoine, education, creation, bibliotheques, musees, archives");
		this.competences.put("sports et loisirs","subventions, tourisme");
		this.competences.put("Amenagement du territoir","Schema regional (elaboration), contrat de projet etat/region");
		this.competences.put("Environnement","Espaces naturels, Parcs Regionaux, participation au schema deamenagement et de gestion des eaux");
		this.competences.put("Grands equipements","Ports fluviaux, Aerodromes");
		this.competences.put("Developpement economique","Aides directes et indirectes");
	}
	
	public CompetencesRegion() {
		this(null);
	}

}
