
public class CompetencesEtat extends Competences {

	public CompetencesEtat(Competences suivant) {
		super("Etat", suivant);
		
		this.competences.put("Formation Professionnelle et Apprentissage","Definition de la politique nationale et mise en euvre pour certains publics");
		this.competences.put("Enseignement","Universites (betiments, personnel), Politique educative");
		this.competences.put("Culture et vie sociale","patrimoine, education, creation, bibliotheques, musees, archives");
		this.competences.put("sports et loisirs","formation, subventions, tourisme");
		this.competences.put("Action sociale et medico-sociale","allocation deadulte handicape, centre dehebergement et de reinsertion sociale");
		this.competences.put("Urbanisme","projet deinteret general, operations deinteret national, directive territoriale deamenagement");
		this.competences.put("Amenagement du territoir","politique d'amenagement du territoir, contrat de projet etat/region");
		this.competences.put("Environnement","Espaces naturels, Parcs Nationaux, schema deamenagement et de gestion des eaux, energie");
		this.competences.put("Grands equipements","Ports autonomes et deinteret national, Voies navigables, Aerodromes");
		this.competences.put("Developpement economique","Politique economique");
		this.competences.put("Securite","Police generale et polices speciales");
	}
	
	public CompetencesEtat() {
		this(null);
	}

}
