public class FiltreComplexite extends Filtre {
	private int complexite;
	
	public static final int TROP_COMPLEXE = 150, EXTREMEMENT_COMPLEXE = 300;
	
	public FiltreComplexite(int complexite) {
		this.complexite = complexite;
	}
	
	@Override
	public boolean userStoryAEnlever(UserStory userStory) {
		return userStory.getComplexiteEnPoints() > this.complexite;
	}	
}
