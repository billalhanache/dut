

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ProductOwner {

	private BackLogProduct sonBackLog;

	public ProductOwner(String nameProduct) {
		this.sonBackLog = new BackLogProduct(nameProduct);
		this.sonBackLog.add(new UserStory(TypeUserStory.BUG, "probl�me dans panier - suppression trajet al�atoire", 50, 10));
		this.sonBackLog.add(new UserStory(TypeUserStory.BUG, "connexion Banque Populaire pour paiement s�curis�", 5, 100));
		this.sonBackLog.add(new UserStory(TypeUserStory.BUG, "connexion Caisse Epargne pour paiement s�curis�", 5, 100));
		this.sonBackLog.add(new UserStory(TypeUserStory.BUG, "connexion Banque Rotschild pour paiement s�curis�", 5, 1));
		this.sonBackLog.add(new UserStory(TypeUserStory.FONCTIONALITY, "historique derni�re recherche � remplacer par historique des voyages", 30, 15));
		this.sonBackLog.add(new UserStory(TypeUserStory.FONCTIONALITY, "calcul gain �mission carbonne pour m�me voyage en voiture", 35, 50));
		this.sonBackLog.add(new UserStory(TypeUserStory.FONCTIONALITY, "calcul gain �mission carbonne pour m�me voyage en avion s'il eiste", 50, 50));
		this.sonBackLog.add(new UserStory(TypeUserStory.FONCTIONALITY, "calcul gain ou perte pour m�me voyage en voiture", 20, 20));
		this.sonBackLog.add(new UserStory(TypeUserStory.FONCTIONALITY, "calcul gain ou perte pour m�me voyage en avion", 25, 25));
		this.sonBackLog.add(new UserStory(TypeUserStory.NOTDONE, "synchronisation des donn�es WEB et appli mobile", 144, 200));
		this.sonBackLog.add(new UserStory(TypeUserStory.NOTDONE, "protection par mot de passe", 77, 14));
		this.sonBackLog.add(new UserStory(TypeUserStory.POC, "vente flash derni�re minute", 75, 12));
		this.sonBackLog.add(new UserStory(TypeUserStory.POC, "vente priv�e pour bons clients", 95, 12));
		this.sonBackLog.add(new UserStory(TypeUserStory.TECHNICAL, "dette : faire des tests automatis�s par les IHMs", 350, 250));
		this.sonBackLog.add(new UserStory(TypeUserStory.TECHNICAL, "dette : faire des tests fonctionnels automatis�s pour �viter r�gression", 410, 100));
		this.sonBackLog.add(new UserStory(TypeUserStory.TECHNICAL, "mettre en place l'int�gration continue", 31, 350));
	}

	public SprintBackLog productToSprintBacklogStrategieOneDeprecated() {
		List<UserStory> aFiltrer = new ArrayList<UserStory>(this.sonBackLog.getUserStories());

		// on enl�ve les user stories trop complexes
		Iterator<UserStory> it1 = aFiltrer.iterator();
		while (it1.hasNext()) {
			UserStory userStory = it1.next();
			if  (userStory.getComplexiteEnPoints() > 150)
				it1.remove();
		}

		// on enl�ve les user stories qui ne rapportent pas assez
		Iterator<UserStory> it2 = aFiltrer.iterator();
		while (it2.hasNext()) {
			UserStory userStory = it2.next();
			if  (userStory.getBusinessValueEnEuro() < 30)
				it2.remove();
		}

		// on enl�ve les user stories n�cessaires mais non fonctionnels
		Iterator<UserStory> it3 = aFiltrer.iterator();
		while (it3.hasNext()) {
			UserStory userStory = it3.next();
			if  (userStory.getType() == TypeUserStory.TECHNICAL)
				it3.remove();
		}

		return new SprintBackLog(99, aFiltrer);
	}

	public SprintBackLog productToSprintBacklogStrategieOne() {
		List<UserStory> aFiltrer = new ArrayList<UserStory>(this.sonBackLog.getUserStories());

		FiltreComplexite filtreTropComplexe = new FiltreComplexite(FiltreComplexite.TROP_COMPLEXE);
		FiltreBusinessValue filtreRapportePasAssez = new FiltreBusinessValue(FiltreBusinessValue.PAS_ASSEZ);
		FiltreType filtreNonFonctionnel = new FiltreType(TypeUserStory.TECHNICAL);

		filtreTropComplexe.setSuivant(filtreRapportePasAssez);
		filtreRapportePasAssez.setSuivant(filtreNonFonctionnel);

		filtreTropComplexe.appliquerFiltre(aFiltrer);

		return new SprintBackLog(99, aFiltrer);
	}

	public SprintBackLog productToSprintBacklogStrategieTwoDeprecated() {
		List<UserStory> aFiltrer = new ArrayList<UserStory>(this.sonBackLog.getUserStories());

		// on enl�ve les user stories exploratoires
		Iterator<UserStory> it1 = aFiltrer.iterator();
		while (it1.hasNext()) {
			UserStory userStory = it1.next();
			if  (userStory.getType() == TypeUserStory.POC)
				it1.remove();
		}

		// on enl�ve les user stories qui ne rapportent pas beaucoup
		Iterator<UserStory> it2 = aFiltrer.iterator();
		while (it2.hasNext()) {
			UserStory userStory = it2.next();
			if  (userStory.getBusinessValueEnEuro() < 10)
				it2.remove();
		}

		// on enl�ve les user stories extremement complexes
		Iterator<UserStory> it3 = aFiltrer.iterator();
		while (it3.hasNext()) {
			UserStory userStory = it3.next();
			if  (userStory.getComplexiteEnPoints() > 300)
				it3.remove();
		}

		return new SprintBackLog(99, aFiltrer);
	}

	public SprintBackLog productToSprintBacklogStrategieTwo() {
		List<UserStory> aFiltrer = new ArrayList<UserStory>(this.sonBackLog.getUserStories());

		FiltreType filtreTypeExploratoire = new FiltreType(TypeUserStory.POC);
		FiltreBusinessValue filtreRapportePasBeaucoup = new FiltreBusinessValue(FiltreBusinessValue.PAS_BEAUCOUP);
		FiltreComplexite filtreExtremementComplexe = new FiltreComplexite(FiltreComplexite.EXTREMEMENT_COMPLEXE);
		
		filtreTypeExploratoire.setSuivant(filtreRapportePasBeaucoup);
		filtreRapportePasBeaucoup.setSuivant(filtreExtremementComplexe);
		
		filtreTypeExploratoire.appliquerFiltre(aFiltrer);
		
		return new SprintBackLog(99, aFiltrer);
	}

	public static void main(String[] args) {
		ProductOwner martineDeLaSNCF = new ProductOwner("Oui_SNCF");
		System.out.println(martineDeLaSNCF.sonBackLog);

		// premi�re strat�gie pour d�finir le sprint Backlog
		SprintBackLog sprint99premiere = martineDeLaSNCF.productToSprintBacklogStrategieOneDeprecated();
		System.out.println(sprint99premiere);

		// deuxi�me strat�gie pour d�finir le sprint Backlog
		SprintBackLog sprint99deuxieme = martineDeLaSNCF.productToSprintBacklogStrategieTwoDeprecated();
		System.out.println(sprint99deuxieme);
	}

}
