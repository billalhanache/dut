public class FiltreType extends Filtre {
	private TypeUserStory type;
	
	public FiltreType(TypeUserStory type) {
		this.type = type;
	}
	
	@Override
	public boolean userStoryAEnlever(UserStory userStory) {
		return userStory.getType() == this.type;
	}
}
