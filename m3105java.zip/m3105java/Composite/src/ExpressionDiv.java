public class ExpressionDiv extends ExpressionComposite {
	public int evaluate() {
		int result = this.children.get(0).evaluate();
		for(int i = 1; i < this.children.size(); i++) {
			if(this.children.get(i).evaluate() == 0) return Integer.MAX_VALUE;
			result /= this.children.get(i).evaluate();
		}
		return result;
	}
}
