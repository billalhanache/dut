import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ EntierTest.class, ExpressionDivTest.class, ExpressionMoinsTest.class, ExpressionMultTest.class,
		ExpressionPlusTest.class })
public class AllTests {

}
