import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ExpressionDivTest {
	private ExpressionDiv instance;
	private ExpressionDiv instance1;
	private ExpressionDiv instance2;
	private ExpressionDiv instanceZero;
	
	@Before
	public void setUp() throws Exception {
		this.instance = new ExpressionDiv();
		this.instance.add(new Entier(1));
		
		this.instance1 = new ExpressionDiv();
		this.instance1.add(new Entier(15));
		this.instance1.add(new Entier(5));
		
		this.instance2 = new ExpressionDiv();
		this.instance2.add(new Entier(24));
		this.instance2.add(new Entier(2));
		this.instance2.add(new Entier(-3));
		
		this.instanceZero = new ExpressionDiv();
		this.instanceZero.add(new Entier(1));
		this.instanceZero.add(new Entier(0));
	}

	@After
	public void tearDown() throws Exception {
		this.instance = null;
		this.instance1 = null;
		this.instance2 = null;
	}

	@Test
	public void testInstance() {		
		assertEquals(1, this.instance.evaluate());
	}
	
	@Test
	public void testInstance1() {
		assertEquals(3, this.instance1.evaluate());
	}
	
	@Test
	public void testInstance2() {
		assertEquals(-4, this.instance2.evaluate());
	}
	
	@Test
	public void testDivisionPerZero() {
		assertEquals(Integer.MAX_VALUE, this.instanceZero.evaluate());
	}

}
