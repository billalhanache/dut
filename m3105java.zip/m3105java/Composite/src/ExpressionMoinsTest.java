import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ExpressionMoinsTest {
	private ExpressionMoins instance;
	private ExpressionMoins instance1;
	private ExpressionMoins instance2;
	
	@Before
	public void setUp() throws Exception {
		this.instance = new ExpressionMoins();
		this.instance.add(new Entier(1));
		
		this.instance1 = new ExpressionMoins();
		this.instance1.add(new Entier(5));
		this.instance1.add(new Entier(7));
		
		this.instance2 = new ExpressionMoins();
		this.instance2.add(new Entier(1));
		this.instance2.add(new Entier(2));
		this.instance2.add(new Entier(-3));
	}

	@After
	public void tearDown() throws Exception {
		this.instance = null;
		this.instance1 = null;
		this.instance2 = null;
	}

	@Test
	public void testInstance() {		
		assertEquals(1, this.instance.evaluate());
	}
	
	@Test
	public void testInstance1() {
		assertEquals(-2, this.instance1.evaluate());
	}
	
	@Test
	public void testInstance2() {
		assertEquals(2, this.instance2.evaluate());
	}

}
