public class ExpressionPlus extends ExpressionComposite {
	public int evaluate() {
		int result = this.children.get(0).evaluate();
		for(int i = 1; i < this.children.size(); i++) {
			result += this.children.get(i).evaluate();
		}
		return result;
	}
}
