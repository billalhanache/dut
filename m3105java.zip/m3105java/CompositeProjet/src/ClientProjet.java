
public class ClientProjet {
	public static void main(String[] args) {
		Tache definitionExigencesStrategiques = new Tache("Définition des exigences stratégiques", Responsable.DE);
		
		Tache etudeExistant = new Tache("Etude de l'existant", Responsable.AN);
		Delivrable etatArt = new Delivrable("Etat de l'art", Responsable.AN, 3D);
		etudeExistant.add(etatArt);
		
		Tache ebaucheSolutions = new Tache("Ebauche de solutions", Responsable.DE);
		Delivrable elementsSolution = new Delivrable("Eléments de solution", Responsable.DE, 2D);
		ebaucheSolutions.add(elementsSolution);
		
		Tache analyseBonnesPratiques = new Tache("Analyse des bonnes pratiques de l'entreprise", Responsable.CS);
		Delivrable guideBonnesPratiques = new Delivrable("Guide des bonnes pratiques", Responsable.CS, 1);
		analyseBonnesPratiques.add(guideBonnesPratiques);
		
		definitionExigencesStrategiques.add(etudeExistant);
		definitionExigencesStrategiques.add(ebaucheSolutions);
		definitionExigencesStrategiques.add(analyseBonnesPratiques);
		
		Tache analysePreliminaire = new Tache("Analyse préliminaire", Responsable.AN);
		
		Tache contourSysteme = new Tache("Contour du système", Responsable.AN);
		Delivrable ddcu = new Delivrable("Diagramme de cas d'utilisation", Responsable.AN, .5D);
		contourSysteme.add(ddcu);

		Tache analyseExistant = new Tache("Analyse de l'existant", Responsable.AN);
		Delivrable modelesStructurels = new Delivrable("Modèles structurels de l'entreprise", Responsable.AN, 2.5D);
		Delivrable modelesDynamiques= new Delivrable("Modèles dynamiques de l'entreprise", Responsable.AN, 2.5D);
		analyseExistant.add(modelesStructurels);
		analyseExistant.add(modelesDynamiques);
		
		Tache gestionRessources = new Tache("Gestion des ressources", Responsable.RH);
		Delivrable planUtilisation = new Delivrable("Plan d'utilisation des ressources", Responsable.RH, .5D);
		gestionRessources.add(planUtilisation);
		
		Tache explorationPrototypage = new Tache("Exploration par prototypage", Responsable.DV);
		Delivrable prototypes = new Delivrable("Prototypes", Responsable.DV, 4D);
		Delivrable recetteClient = new Delivrable("Recette client", Responsable.CP, 4D);
		explorationPrototypage.add(prototypes);
		explorationPrototypage.add(recetteClient);
		
		analysePreliminaire.add(contourSysteme);
		analysePreliminaire.add(analyseExistant);
		analysePreliminaire.add(gestionRessources);
		analysePreliminaire.add(explorationPrototypage);
		
		Tache definitionExigencesUtilisateurs = new Tache("Définition des exigences utilisateurs", Responsable.CS);
		
		Tache definitionTemplates = new Tache("Définition des templates d'interface", Responsable.DV);
		Delivrable templateInterface = new Delivrable("Template d'interfaces", Responsable.DV, 2D);
		definitionTemplates.add(templateInterface);
		
		Tache gestionAspects = new Tache("Gestion des aspects distribuées", Responsable.XP);
		Delivrable diagrammeArchitecture = new Delivrable("Diagrammes de l'architecture", Responsable.XP, 2D);
		Delivrable diagrammeDeploiement = new Delivrable("Diagrammes de déploiement", Responsable.XP, 2D);
		gestionAspects.add(diagrammeArchitecture);
		gestionAspects.add(diagrammeDeploiement);
		
		definitionExigencesUtilisateurs.add(definitionTemplates);
		definitionExigencesUtilisateurs.add(gestionAspects);
		definitionExigencesUtilisateurs.add(explorationPrototypage);
		
		Tache definitionExigenceDeveloppement = new Tache("Définition des exigences de développement", Responsable.XP);
	
		Tache definitionVisibilite = new Tache("Définition de la visibilité du processus", Responsable.CP);
		Delivrable normesConduite = new Delivrable("Normes de conduite de projet", Responsable.DE, 1D);
		definitionVisibilite.add(normesConduite);
		
		Tache revisionInterfaces = new Tache("Révision des interfaces utilisateurs", Responsable.DV);
		Delivrable prototypes2 = new Delivrable("Prototypes", Responsable.DV, 2D);
		Delivrable recetteClient2 = new Delivrable("Recette client", Responsable.CP, 2D);
		revisionInterfaces.add(prototypes2);
		revisionInterfaces.add(recetteClient2);
		
		definitionExigenceDeveloppement.add(definitionVisibilite);
		definitionExigenceDeveloppement.add(revisionInterfaces);
		
		Tache.PROJET.add(definitionExigencesStrategiques);
		Tache.PROJET.add(analysePreliminaire);
		Tache.PROJET.add(definitionExigencesUtilisateurs);
		Tache.PROJET.add(definitionExigenceDeveloppement);
		
		System.out.println(Tache.PROJET.toString(""));
	}
}
