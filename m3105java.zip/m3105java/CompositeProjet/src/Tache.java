import java.util.List;
import java.text.NumberFormat;
import java.util.ArrayList;

public class Tache extends TacheAbstraite {
	private List<TacheAbstraite> taches;
	
	public static Tache PROJET = new Tache("Analyse", Responsable.FS);
	
	public Tache(String nom, Responsable responsable) {
		super(nom, responsable);
		this.taches = new ArrayList<>();
	}
	
	public void add(TacheAbstraite tacheAbstraite) {
		this.taches.add(tacheAbstraite);
	}
	
	public void remove(TacheAbstraite tacheAbstraite) {
		this.taches.remove(tacheAbstraite);
	}
	
	public List<TacheAbstraite> getChildren() {
		return this.taches;
	}
	
	public double getTempsRequis() {
		double tempsRequis = 0D;
		for(TacheAbstraite ta : this.taches) {
			tempsRequis += ta.getTempsRequis();
		}
		return tempsRequis;
	}
	
	public String toString(String nbEspaces) {
		String result = nbEspaces + this.nom;
		result += " ".repeat(50 - result.length());
		result += "(" + this.responsable.getInitiales() + ")";
		if(this.isDeepTask()) result += " --> " + NumberFormat.getNumberInstance().format(this.getTempsRequis()) + " j";
		result += "\n";
		nbEspaces += "  ";
		for(TacheAbstraite ta : this.taches) {
			result += ta.toString(nbEspaces) + "\n";
		}
		return result;
	}
	
	public boolean isDeepTask() {
		for(TacheAbstraite ta : this.taches) {
			if(ta instanceof Tache) return false;
		}
		return true;
	}
}
