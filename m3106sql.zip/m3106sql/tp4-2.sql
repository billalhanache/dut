select * from T;

update T set b = 'F' where a = 2;
rollback;
commit;

update t set b = 'B1' where a = 3;
update t set b = 'B2' where a = 2;