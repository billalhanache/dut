
public class MonApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	testScenario3();

	}
	
		// je vais voir ma grand mere affaiblie afin de lui donner les courses que j'ai fait pour elle
		private static void testScenario3() {
			Attestation monAttestation = new Attestation();
			// Informations personnelles ?
			monAttestation.getPersonne().setNom("Hanache");
			monAttestation.getPersonne().setPrenom("Billal");
			monAttestation.getPersonne().getDate_Naissance().setJour(6);
			monAttestation.getPersonne().getDate_Naissance().setMois(01);
			monAttestation.getPersonne().getDate_Naissance().setAnnee(2000);
			monAttestation.getPersonne().setLieu_Naissance("Toulouse");
			monAttestation.getPersonne().getAdresse().setRue("47 rue Charles Geniaux");
			monAttestation.getPersonne().getAdresse().setVille("Toulouse");
			monAttestation.getPersonne().getAdresse().setCode_Postal(31100);
			// Motif de sortie
			monAttestation.setMotif(Motif_Deplacement.FAMILLE);
			// Date et Heure du deplacement de l'aller
			monAttestation.getDate_Sortie().setJour(10);
			monAttestation.getDate_Sortie().setMois(12);
			monAttestation.getDate_Sortie().setAnnee(2020);
			monAttestation.getHeure_Sortie().setHeures(10);
			monAttestation.getHeure_Sortie().setMinutes(30);
			// clonage pour le retour afin de rentrer chez moi
			Attestation retour = monAttestation.clone();
			retour.getHeure_Sortie().setHeures(12);
			retour.getHeure_Sortie().setMinutes(30);
			// genérer et afficher les attestations aller et retour
			System.out.println("Mon attestation__________\n\n");
			System.out.println(monAttestation.generer());
			System.out.println("attestation retour__________\n\n");
			System.out.println(retour.generer());
		}
		
	}

