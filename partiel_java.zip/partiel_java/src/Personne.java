
public class Personne implements Cloneable {
	
	public String nom;
	public String prenom;
	public Date date_Naissance;
	public String lieu_Naissance;
	public Adresse adresse;
	
	public Personne() {
		this.adresse = new Adresse();
		this.date_Naissance = new Date();
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	
	public Date getDate_Naissance() {
		return date_Naissance;
	}

	public void setDate_Naissance(Date date_Naissance) {
		this.date_Naissance = date_Naissance;
	}
	
	public String getLieu_Naissance() {
		return lieu_Naissance;
	}

	public void setLieu_Naissance(String lieu_Naissance) {
		this.lieu_Naissance = lieu_Naissance;
	}
	
	public Adresse getAdresse() {
		return adresse;
	}
	
	public Personne clone() {
		Personne clone = null;
		
		try {
			clone = (Personne) super.clone();
			clone.date_Naissance = this.date_Naissance.clone();
			clone.adresse = this.adresse.clone();
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return clone;
			
		
	}
	
}