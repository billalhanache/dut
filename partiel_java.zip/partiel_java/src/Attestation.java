public class Attestation implements Cloneable {

	private Personne personne;
	private Motif_Deplacement motif;
	private Date date_Sortie;
	private Heure heure_Sortie;

	public Attestation() {
		this.personne = new Personne();
		this.date_Sortie = new Date();
		this.heure_Sortie = new Heure();
	}
	
	public String generer() {
		StringBuffer sb = new StringBuffer();
		sb.append("\t\tATTESTATION DE DÉPLACEMENT DÉROGATOIRE\n\n");
		sb.append("\tEn application du décret n°2020-1310 du 29 octobre 2020 prescrivant les mesures générales\n");
		sb.append("\tnécessaires pour faire face à l'épidémie de Covid19 dans le cadre de l'état d'urgence sanitaire\n\n");
		sb.append("Je soussigné(e),\n\n");
		sb.append("Mme/M. : ");
		sb.append(this.getPersonne().getPrenom() + ' ');
		sb.append(this.getPersonne().getNom() + "\n\n");
		sb.append("Né(e) le: ");
		sb.append(this.getPersonne().getDate_Naissance() + "\t\t\t");
		sb.append("à : " + this.getPersonne().getLieu_Naissance() + "\n\n");
		sb.append("Demeurant : " + this.getPersonne().getAdresse() + "\n\n");
		sb.append("certifie que mon déplacement est lié au motif suivant autorisé par le décret\n");
		sb.append("n°2020-1310 du 29 octobre 2020 prescrivant les mesures générales nécessaires pour faire face à\n");
		sb.append("l'épidémie de Covid19 dans le cadre de l'état d'urgence sanitaire :\n\n");
		sb.append(this.motif.getMotifEnDur() + "\n\n" );
		sb.append("Fait à : " + this.getPersonne().getAdresse().getVille() + "\n\n");
		sb.append("Le : " + this.getDate_Sortie() + "\t\tà : " + this.getHeure_Sortie() + '\n');
		sb.append("(Date et heure de début de sortie à mentionner obligatoirement)\n");
		sb.append("Signature :\n");
		return sb.toString();
	}

	public Personne getPersonne() {
		return this.personne;
	}

	public void setMotif(Motif_Deplacement motif) {
		this.motif = motif;
	}
	
	public Date getDate_Sortie() {
		return date_Sortie;
	}
	
	public void setDate_Sortie(Date date_Sortie) {
		this.date_Sortie = date_Sortie;
	}
	
	public Heure getHeure_Sortie() {
		return heure_Sortie;
	}

	public void setHeure_Sortie(Heure heure_Sortie) {
		this.heure_Sortie = heure_Sortie;
	}
	
	public Attestation clone() {
		
		Attestation clone = null;
		
		try {
			clone = (Attestation) super.clone();
			clone.date_Sortie = this.date_Sortie.clone();
			clone.personne = this.personne.clone();
			clone.heure_Sortie = this.heure_Sortie.clone();
			
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return clone;
		
		
	}
	
	
}
