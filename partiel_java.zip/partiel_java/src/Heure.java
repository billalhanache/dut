import java.util.Calendar;

public class Heure implements Cloneable {

	private int heures;
	private int minutes;
	
	public String toString() {
		return this.valueOf(heures) + ':' + this.valueOf(minutes);
	}
	
	private String valueOf(int data) {
		String result = String.valueOf(data);
		if (result.length() == 1)
			return "0" + result;
		else
			return result;
	}
	
	public void updateHeureCourante() {
		Calendar calendar = Calendar.getInstance();
		this.setHeures(calendar.get(Calendar.HOUR_OF_DAY));
		this.setMinutes(calendar.get(Calendar.MINUTE));
	}

	public void setHeures(int heures) {
		this.heures = heures;
	}

	public void setMinutes(int minutes) {
		this.minutes = minutes;
	}
	
	public Heure clone() {
		
		Heure clone = null;
		
		try {
			clone = (Heure) super.clone();
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return clone;
		
	}
	
	
}