import java.util.Calendar;

public class Date implements Cloneable {
	
	private int jour;
	private int mois;
	private int annee;

	public String toString() {
		return valueOf(jour) + '/' + valueOf(mois) + '/' + String.valueOf(annee);
	}
	
	private String valueOf(int data) {
		String result = String.valueOf(data);
		if (result.length() == 1)
			return "0" + result;
		else
			return result;
	}
	
	public void updateDateDuJour() {
		Calendar calendar = Calendar.getInstance(); 
		this.setAnnee(calendar.get(Calendar.YEAR));
		this.setMois(calendar.get(Calendar.MONTH) + 1);
		this.setJour(calendar.get(Calendar.DAY_OF_MONTH));
	}

	public void setJour(int jour) {
		this.jour = jour;
	}

	public void setMois(int mois) {
		this.mois = mois;
	}

	public void setAnnee(int annee) {
		this.annee = annee;
	}
	
	
	public Date clone() {
		
		Date clone = null;
		
		try {
			clone = (Date) super.clone();
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return clone;
		
	}
	
}