public class Adresse implements Cloneable {
	public String rue;
	public String ville;
	public int code_Postal;
	
	
	public String toString() {
		return rue + ' ' + String.valueOf(code_Postal) + ' ' + ville; 
	}
	
	public String getVille() {
		return ville;
	}

	public void setRue(String adresse) {
		this.rue = adresse;
	}

	public void setVille(String ville) {
		this.ville = ville;
	}

	public void setCode_Postal(int code_Postal) {
		this.code_Postal = code_Postal;
	}
	
	public Adresse clone() {
		
		Adresse clone = null;
		try {
			clone = (Adresse) super.clone();
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return clone;
		
	}
	
}