public enum Motif_Deplacement  implements Cloneable  {
	BOULOT	("\tDéplacements entre le domicile et le lieu d’exercice de l’activité professionnelle ou un\n" +
			"\tétablissement d’enseignement ou de formation, déplacements professionnels ne pouvant\n" + 
			"\têtre différés, déplacements pour un concours ou un examen."),
	ACHATS	("\tDéplacements pour effectuer des achats de fournitures nécessaires à l'activité\n" +
			"\tprofessionnelle, des achats de première nécessité dans des établissements dont les\n" + 
			"\tactivités demeurent autorisées, le retrait de commande et les livraisons à domicile."),
	SOINS	("\tConsultations, examens et soins ne pouvant être assurés à distance et l’achat de\n" +
			"\tmédicaments."),
	FAMILLE	("\tDéplacements pour motif familial impérieux, pour l'assistance aux personnes vulnérables\n" +
			"\tet précaires ou la garde d'enfants."),
	HANDICAP("\tDéplacement des personnes en situation de handicap et leur accompagnant."),
	SPORT	("\tDéplacements brefs, dans la limite d'une heure quotidienne et dans un rayon maximal\n" +
			"\td'un kilomètre autour du domicile, liés soit à l'activité physique individuelle des\n" + 
			"\tpersonnes, à l'exclusion de toute pratique sportive collective et de toute proximité avec\n" + 
			"\td'autres personnes, soit à la promenade avec les seules personnes regroupées dans un\n" + 
			"\tmême domicile, soit aux besoins des animaux de compagnie."),
	ADMINISTRATIF("\tConvocation judiciaire ou administrative et pour se rendre dans un service public"),
	INTERETS_GENERAL("\tParticipation à des missions d'intérêt général sur demande de l'autorité administrative"),
	ENFANTS	("\tDéplacement pour chercher les enfants à l’école et à l’occasion de leurs activités\n" +
			"\tpériscolaires");

	private String motif;  

	private Motif_Deplacement(String motif){
		this.motif = motif;
	}

	public String getMotifEnDur() {  
		return this.motif ;  
	} 
	
	
}
