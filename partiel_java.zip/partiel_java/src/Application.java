
public class Application {

	public static void main(String[] args) {
		Attestation monAttestation = new Attestation();
		// Qui suis-je ?
		monAttestation.getPersonne().setNom("Leblanc");
		monAttestation.getPersonne().setPrenom("Herve");
		monAttestation.getPersonne().getDate_Naissance().setJour(7);
		monAttestation.getPersonne().getDate_Naissance().setMois(10);
		monAttestation.getPersonne().getDate_Naissance().setAnnee(1962);
		monAttestation.getPersonne().setLieu_Naissance("Metz");
		monAttestation.getPersonne().getAdresse().setRue("57 rue des troubadours");
		monAttestation.getPersonne().getAdresse().setVille("Toulouse");
		monAttestation.getPersonne().getAdresse().setCode_Postal(31000);
		// Motif
		monAttestation.setMotif(Motif_Deplacement.ACHATS);
		// Date et Heure
		monAttestation.getDate_Sortie().updateDateDuJour();
		monAttestation.getHeure_Sortie().updateHeureCourante();
		System.out.println(monAttestation.generer());
	}
}
