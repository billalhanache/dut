
public class Application_Clonage {

	public static void main(String[] args) {
		testScenario1();
		testScenario2();
	}

	// Je vais courir avec mes deux enfants qui habitent avec moi demain soir à 17 heures
	private static void testScenario1() {
		Attestation monAttestation = new Attestation();
		// Qui suis-je ?
		monAttestation.getPersonne().setNom("Leblanc");
		monAttestation.getPersonne().setPrenom("Herve");
		monAttestation.getPersonne().getDate_Naissance().setJour(7);
		monAttestation.getPersonne().getDate_Naissance().setMois(10);
		monAttestation.getPersonne().getDate_Naissance().setAnnee(1962);
		monAttestation.getPersonne().setLieu_Naissance("Metz");
		monAttestation.getPersonne().getAdresse().setRue("57 rue des troubadours");
		monAttestation.getPersonne().getAdresse().setVille("Toulouse");
		monAttestation.getPersonne().getAdresse().setCode_Postal(31000);
		// Motif
		monAttestation.setMotif(Motif_Deplacement.SPORT);
		// Date et Heure
		monAttestation.getDate_Sortie().setJour(10);
		monAttestation.getDate_Sortie().setMois(11);
		monAttestation.getDate_Sortie().setAnnee(2020);
		monAttestation.getHeure_Sortie().setHeures(17);
		monAttestation.getHeure_Sortie().setMinutes(0);
		// clonage pour Arthur
		Attestation arthur = monAttestation.clone();
		arthur.getPersonne().setPrenom("Arthur");
		arthur.getPersonne().getDate_Naissance().setJour(18);
		arthur.getPersonne().getDate_Naissance().setMois(6);
		arthur.getPersonne().getDate_Naissance().setAnnee(1991);
		arthur.getPersonne().setLieu_Naissance("Montpellier");
		arthur.getPersonne().getAdresse().setRue("59 rue des troubadours");
		// clonage pour Vincent (Ils sont jumeaux)
		Attestation vincent = arthur.clone();
		vincent.getPersonne().setPrenom("Vincent");
		vincent.getPersonne().getAdresse().setRue("61 rue des troubadours");
		// genérer et afficher les attestations
		System.out.println("Mon attestation__________\n\n");
		System.out.println(monAttestation.generer());
		System.out.println("attestation Arthur__________\n\n");
		System.out.println(arthur.generer());
		System.out.println("attestation Vincent__________\n\n");
		System.out.println(vincent.generer());
	}

	// Je vais Travailler à l'IUT aujourd'hui et demain
	private static void testScenario2() {
		Attestation monAttestation = new Attestation();
		// Qui suis-je ?
		monAttestation.getPersonne().setNom("Leblanc");
		monAttestation.getPersonne().setPrenom("Herve");
		monAttestation.getPersonne().getDate_Naissance().setJour(7);
		monAttestation.getPersonne().getDate_Naissance().setMois(10);
		monAttestation.getPersonne().getDate_Naissance().setAnnee(1962);
		monAttestation.getPersonne().setLieu_Naissance("Metz");
		monAttestation.getPersonne().getAdresse().setRue("57 rue des troubadours");
		monAttestation.getPersonne().getAdresse().setVille("Toulouse");
		monAttestation.getPersonne().getAdresse().setCode_Postal(31000);
		// Motif
		monAttestation.setMotif(Motif_Deplacement.BOULOT);
		// Date et Heure
		monAttestation.getDate_Sortie().setJour(9);
		monAttestation.getDate_Sortie().setMois(11);
		monAttestation.getDate_Sortie().setAnnee(2020);
		monAttestation.getHeure_Sortie().setHeures(9);
		monAttestation.getHeure_Sortie().setMinutes(30);
		// clonage pour le soir
		Attestation retour = monAttestation.clone();
		retour.getHeure_Sortie().setHeures(18);
		retour.getHeure_Sortie().setMinutes(30);
		// clonage pour l'aller du lendemain 
		Attestation aller_Lendemain = monAttestation.clone();
		aller_Lendemain.getDate_Sortie().setJour(10);
		// clonage pour le retour du lendemain
		Attestation retour_Lendemain = retour.clone();
		retour_Lendemain.getDate_Sortie().setJour(10);
		// genérer et afficher les attestations
		System.out.println("Mon attestation__________\n\n");
		System.out.println(monAttestation.generer());
		System.out.println("attestation retour__________\n\n");
		System.out.println(retour.generer());
		System.out.println("attestation aller Lendemain__________\n\n");
		System.out.println(aller_Lendemain.generer());
		System.out.println("attestation retour Lendemain__________\n\n");
		System.out.println(retour_Lendemain.generer());
	}
}
